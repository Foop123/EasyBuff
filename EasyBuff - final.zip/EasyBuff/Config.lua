--[[
  EasyBuff - Config.lua
  Minimap icon + scrolling settings window.
    * checkbox for every reminder that applies to your class
    * custom buff box: paste a spell ID, a spell name, or shift-click a spell link
      (from chat or the spellbook) / an item link while the box has focus
]]

local ADDON, ns = ...
local D = ns.Data

local C, DB, playerClass
local frame, sf, child, bar, input, feedback
local refreshers, customRows = {}, {}
local customListY = 0                 -- relative to the custom-buff section frame (cs)
local ss, cs, ssBaseY, ssStaticH, csStaticH, stockListY    -- stock section / custom section frames
local stockInput, stockFeedback
local stockRows = {}
local minimapBtn
local QMARK = "Interface\\Icons\\INV_Misc_QuestionMark"
local COLW = 196

local function listHas(list, v)
    if not list then return false end
    for _, c in ipairs(list) do if c == v then return true end end
    return false
end

local function tooltip(owner, text)
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    GameTooltip:SetText(text, 1, 1, 1, 1, true)
    GameTooltip:Show()
end

--------------------------------------------------------------------------
-- minimap button
--------------------------------------------------------------------------
local atan2 = math.atan2 or math.atan

-- badge = number of active reminders; icon greys out while the addon is off
function ns.OnCount(n)
    local b = minimapBtn
    if not b or not b.badge then return end
    if n and n > 0 and DB and DB.enabled then
        b.badgeNum:SetText(n > 99 and "99" or tostring(n))
        b.badge:Show()
        if DB.flash then b.badgeAnim:Play() else b.badgeAnim:Stop() end
    else
        b.badgeAnim:Stop()
        b.badge:Hide()
    end
end

local function refreshMinimap()
    if not minimapBtn then return end
    minimapBtn.icon:SetDesaturated(not DB.enabled)
    ns.OnCount(ns.activeCount or 0)
end

local function positionMinimap()
    if not minimapBtn or not Minimap then return end
    local a = math.rad(DB.minimapAngle or 215)
    local r = (Minimap:GetWidth() / 2) + 5
    minimapBtn:ClearAllPoints()
    minimapBtn:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * r, math.sin(a) * r)
end

local function dragUpdate()
    local mx, my = Minimap:GetCenter()
    local px, py = GetCursorPosition()
    local s = Minimap:GetEffectiveScale()
    px, py = px / s, py / s
    DB.minimapAngle = math.deg(atan2(py - my, px - mx))
    positionMinimap()
end

local function createMinimapButton()
    if not Minimap then return end
    local b = CreateFrame("Button", "EasyBuffMinimapButton", Minimap)
    b:SetSize(32, 32)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:RegisterForDrag("LeftButton")

    local overlay = b:CreateTexture(nil, "OVERLAY")
    overlay:SetSize(54, 54)
    overlay:SetTexture(136430)           -- MiniMap-TrackingBorder
    overlay:SetPoint("TOPLEFT")
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetSize(20, 20)
    bg:SetTexture(136467)                -- UI-Minimap-Background
    bg:SetPoint("TOPLEFT", 7, -5)
    local icon = b:CreateTexture(nil, "ARTWORK")
    icon:SetSize(19, 19)
    icon:SetPoint("TOPLEFT", 7, -5)
    icon:SetTexture("Interface\\Icons\\Spell_Holy_WordFortitude")
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    pcall(function()                     -- round the icon off
        local mask = b:CreateMaskTexture()
        mask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMaskSmall", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
        mask:SetAllPoints(icon)
        icon:AddMaskTexture(mask)
    end)
    b.icon = icon
    b:SetHighlightTexture(136477)        -- UI-Minimap-ZoomButton-Highlight

    -- red badge showing how many reminders are active right now
    local badge = CreateFrame("Frame", nil, b)
    badge:SetSize(16, 16)
    badge:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 1, 1)
    badge:SetFrameLevel(b:GetFrameLevel() + 5)
    local dot = badge:CreateTexture(nil, "BACKGROUND")
    dot:SetAllPoints()
    dot:SetColorTexture(0.85, 0.12, 0.12, 1)
    pcall(function()
        local m = badge:CreateMaskTexture()
        m:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMaskSmall", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
        m:SetAllPoints(dot)
        dot:AddMaskTexture(m)
    end)
    local num = badge:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmall")
    num:SetPoint("CENTER", 0, 0)
    local ag = badge:CreateAnimationGroup()
    ag:SetLooping("BOUNCE")
    local al = ag:CreateAnimation("Alpha")
    al:SetFromAlpha(1); al:SetToAlpha(0.45); al:SetDuration(0.6)
    badge:Hide()
    b.badge, b.badgeNum, b.badgeAnim = badge, num, ag

    b:SetScript("OnDragStart", function(self) self:SetScript("OnUpdate", dragUpdate) end)
    b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    b:SetScript("OnClick", function(_, button)
        if button == "RightButton" then
            DB.enabled = not DB.enabled
            C.markDirty()
            C.say("addon " .. (DB.enabled and "on" or "off"))
            refreshMinimap()
            if frame and frame:IsShown() then for _, f in ipairs(refreshers) do f() end end
        else
            ns.ToggleConfig()
        end
    end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("EasyBuff")
        GameTooltip:AddLine("Left-click: settings", 1, 1, 1)
        GameTooltip:AddLine("Right-click: turn on/off", 1, 1, 1)
        GameTooltip:AddLine("Drag: move icon", 1, 1, 1)
        local n = ns.activeCount or 0
        if n > 0 then
            GameTooltip:AddLine(n .. " reminder" .. (n == 1 and "" or "s") .. " active", 1, 0.5, 0.3)
        end
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)

    minimapBtn = b
    positionMinimap()
    b:SetShown(not DB.hideMinimap)
    refreshMinimap()
end

--------------------------------------------------------------------------
-- widgets
--------------------------------------------------------------------------
local function makeCheck(parent, label, x, y, get, set, tip, width)
    local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cb:SetSize(24, 24)
    cb:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    local t = cb.Text or cb.text
    if not t then
        t = cb:CreateFontString(nil, "OVERLAY")
        t:SetPoint("LEFT", cb, "RIGHT", 2, 0)
    end
    t:SetFontObject("GameFontHighlightSmall")
    t:SetText(label)
    t:SetWidth(width or 150)
    t:SetJustifyH("LEFT")
    t:SetWordWrap(false)
    cb:SetScript("OnClick", function(self)
        set(self:GetChecked() and true or false)
        C.markDirty()
    end)
    if tip then
        cb:SetScript("OnEnter", function(self) tooltip(self, tip) end)
        cb:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end
    cb:SetChecked(get() and true or false)
    refreshers[#refreshers + 1] = function() cb:SetChecked(get() and true or false) end
    return cb
end

local function makeButton(parent, text, x, y, w, onClick)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(w, 22)
    b:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    b:SetText(text)
    b:SetScript("OnClick", onClick)
    return b
end

--------------------------------------------------------------------------
-- custom buffs
--------------------------------------------------------------------------
local function setFeedback(msg, good)
    if not feedback then return end
    feedback:SetText(msg or "")
    if good then feedback:SetTextColor(0.4, 1, 0.4) else feedback:SetTextColor(1, 0.5, 0.4) end
end

-- accepts: spell link, item link (uses the item's on-use spell), plain ID, or spell name
local function parseSpell(text)
    text = strtrim(text or "")
    if text == "" then return nil, "Paste a spell ID, name or link first." end

    local itemID = text:match("|Hitem:(%d+)")
    if itemID and C_Item and C_Item.GetItemSpell then
        local ok, name, sid = pcall(C_Item.GetItemSpell, tonumber(itemID))
        if ok and sid then return sid, name or C.spellName(sid) end
        return nil, "That item has no on-use buff spell. Use the buff's spell ID instead."
    end

    local id = tonumber(text:match("|Hspell:(%d+)") or text:match("^spell:(%d+)") or text:match("^(%d+)$"))
    local linkName = text:match("|h%[(.-)%]|h")
    if id then
        local name = C.spellName(id) or linkName
        if not name then return nil, "Spell ID " .. id .. " not found." end
        return id, name
    end

    local clean = text:gsub("^%[(.*)%]$", "%1")
    local info = C_Spell and C_Spell.GetSpellInfo and C_Spell.GetSpellInfo(clean)
    if type(info) == "table" and info.spellID then return info.spellID, info.name end
    return nil, "No spell found for \"" .. clean .. "\". Try the spell ID."
end

local function addCustom()
    local id, name = parseSpell(input:GetText())
    if not id then setFeedback(name, false); return end
    for _, c in ipairs(DB.custom) do
        if c.id == id then setFeedback(name .. " is already in the list.", false); return end
    end
    DB.custom[#DB.custom + 1] = { id = id, name = name, enabled = true, requireKnown = C.known(id) }
    input:SetText("")
    input:ClearFocus()
    setFeedback("Added " .. name .. " (" .. id .. ").", true)
    ns.RebuildCustom()
    C.markDirty()
end

local function getRow(i)
    local r = customRows[i]
    if r then return r end
    r = CreateFrame("Frame", nil, cs)
    r:SetSize(392, 24)

    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(20, 20)
    r.icon:SetPoint("LEFT", 2, 0)
    r.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)

    r.name = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    r.name:SetPoint("LEFT", r.icon, "RIGHT", 4, 0)
    r.name:SetWidth(100)
    r.name:SetJustifyH("LEFT")
    r.name:SetWordWrap(false)

    local function mini(x, label, tip, key)
        local cb = CreateFrame("CheckButton", nil, r, "UICheckButtonTemplate")
        cb:SetSize(22, 22)
        cb:SetPoint("LEFT", r, "LEFT", x, 0)
        local t = cb.Text or cb.text
        if not t then t = cb:CreateFontString(nil, "OVERLAY"); t:SetPoint("LEFT", cb, "RIGHT", 2, 0) end
        t:SetFontObject("GameFontHighlightSmall")
        t:SetText(label)
        cb:SetScript("OnClick", function(self)
            local c = DB.custom[r.idx]
            if c then c[key] = self:GetChecked() and true or false; C.markDirty() end
        end)
        cb:SetScript("OnEnter", function(self) tooltip(self, tip) end)
        cb:SetScript("OnLeave", function() GameTooltip:Hide() end)
        return cb
    end
    r.on = mini(130, "On", "Show a reminder when this buff is missing.", "enabled")
    r.known = mini(180, "Known only", "Only remind while this spell is in your spellbook. Turn off for consumable or item buffs.", "requireKnown")

    r.del = CreateFrame("Button", nil, r, "UIPanelButtonTemplate")
    r.del:SetSize(62, 20)
    r.del:SetPoint("RIGHT", r, "RIGHT", 0, 0)
    r.del:SetText("Remove")
    r.del:SetScript("OnClick", function()
        table.remove(DB.custom, r.idx)
        ns.RebuildCustom()
        C.markDirty()
    end)

    customRows[i] = r
    return r
end

local function updateScroll()
    if not sf then return end
    sf:UpdateScrollChildRect()
    local max = sf:GetVerticalScrollRange() or 0
    bar:SetMinMaxValues(0, max)
    bar:SetShown(max > 1)
    if sf:GetVerticalScroll() > max then sf:SetVerticalScroll(max) end
end

function ns.RebuildCustom()
    if not frame then return end
    for _, r in ipairs(customRows) do r:Hide() end
    for i, c in ipairs(DB.custom) do
        local r = getRow(i)
        r.idx = i
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", cs, "TOPLEFT", 0, customListY - (i - 1) * 26)
        r.icon:SetTexture(C.spellTex(c.id) or QMARK)
        r.name:SetText(c.name or tostring(c.id))
        r.on:SetChecked(c.enabled ~= false)
        r.known:SetChecked(c.requireKnown and true or false)
        r:Show()
    end
    ns.Relayout()
end

-- Shift-click a spell/item link (chat, bags or spellbook) while one of the boxes has focus
local lastLink, lastLinkT = nil, 0
local function onInsertLink(text)
    if type(text) ~= "string" then return end
    local box
    if input and input:IsVisible() and input:HasFocus() then box = input
    elseif stockInput and stockInput:IsVisible() and stockInput:HasFocus() then box = stockInput end
    if box then
        if text == lastLink and GetTime() - lastLinkT < 0.25 then return end
        lastLink, lastLinkT = text, GetTime()
        box:Insert(text)
    end
end

--------------------------------------------------------------------------
-- stock alerts (low consumables in bags)
--------------------------------------------------------------------------
local S   -- ns.Stock, set in InitConfig

local function itemIcon(id)
    return (id and C_Item and C_Item.GetItemIconByID and C_Item.GetItemIconByID(id)) or QMARK
end

local function setStockFeedback(msg, good)
    if not stockFeedback then return end
    stockFeedback:SetText(msg or "")
    if good then stockFeedback:SetTextColor(0.4, 1, 0.4) else stockFeedback:SetTextColor(1, 0.5, 0.4) end
end

-- accepts: item link, item ID, or item name (names only resolve for items the client has seen)
local function parseItem(text)
    text = strtrim(text or "")
    if text == "" then return nil, "Paste an item ID, link or name first." end
    local id = tonumber(text:match("|Hitem:(%d+)") or text:match("^item:(%d+)") or text:match("^(%d+)$"))
    local linkName = text:match("|h%[(.-)%]|h")
    if not id then
        local clean = text:gsub("^%[(.*)%]$", "%1")
        local okName, foundName = pcall(C_Item.GetItemInfoInstant, clean)
        if okName and foundName then id = foundName end
        if not id then
            return nil, "No item found for \"" .. clean .. "\". Use the item ID, or shift-click the item into the box."
        end
    end
    local okId, foundId = pcall(C_Item.GetItemInfoInstant, id)
    if not okId or not foundId then return nil, "Item ID " .. id .. " not found." end
    if C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, id) end
    local name = (C_Item.GetItemNameByID and C_Item.GetItemNameByID(id)) or linkName
    return id, name
end

local function addStockItem()
    local id, name = parseItem(stockInput:GetText())
    if not id then setStockFeedback(name, false); return end
    for _, it in ipairs(DB.stockItems) do
        if it.id == id then setStockFeedback((name or ("Item " .. id)) .. " is already tracked.", false); return end
    end
    DB.stockItems[#DB.stockItems + 1] = { id = id, name = name, enabled = true, threshold = 5, missing = true }
    stockInput:SetText("")
    stockInput:ClearFocus()
    setStockFeedback("Tracking " .. (name or ("item " .. id)) .. ".", true)
    ns.RebuildStock()
    C.markDirty()
end

-- one row: [icon] [On + name]  [alert-at box]  [At 0]  [count in bags]  [Remove]
local function makeStockRow(parent)
    local r = CreateFrame("Frame", nil, parent)
    r:SetSize(392, 24)

    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(18, 18)
    r.icon:SetPoint("LEFT", 2, 0)
    r.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)

    r.on = CreateFrame("CheckButton", nil, r, "UICheckButtonTemplate")
    r.on:SetSize(22, 22)
    r.on:SetPoint("LEFT", r, "LEFT", 22, 0)
    local t = r.on.Text or r.on.text
    if not t then t = r.on:CreateFontString(nil, "OVERLAY"); t:SetPoint("LEFT", r.on, "RIGHT", 2, 0) end
    t:SetFontObject("GameFontHighlightSmall")
    t:SetWidth(112)
    t:SetJustifyH("LEFT")
    t:SetWordWrap(false)
    r.label = t

    r.thr = CreateFrame("EditBox", nil, r, "InputBoxTemplate")
    r.thr:SetSize(44, 20)
    r.thr:SetPoint("LEFT", r, "LEFT", 172, 0)
    r.thr:SetAutoFocus(false)
    r.thr:SetNumeric(true)
    r.thr:SetMaxLetters(5)
    r.thr:SetJustifyH("CENTER")

    r.miss = CreateFrame("CheckButton", nil, r, "UICheckButtonTemplate")
    r.miss:SetSize(22, 22)
    r.miss:SetPoint("LEFT", r, "LEFT", 228, 0)

    r.count = r:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    r.count:SetPoint("LEFT", r, "LEFT", 284, 0)
    r.count:SetWidth(44)
    r.count:SetJustifyH("LEFT")

    r.del = CreateFrame("Button", nil, r, "UIPanelButtonTemplate")
    r.del:SetSize(58, 20)
    r.del:SetPoint("RIGHT", r, "RIGHT", 0, 0)
    r.del:SetText("Remove")

    local function applyThreshold()
        if not r.st then return end
        local n = tonumber(r.thr:GetText()) or 0
        n = math.max(0, math.min(99999, math.floor(n)))
        r.st.threshold = n
        r.thr:SetText(tostring(n))
        C.markDirty()
        r:Refresh()
    end
    r.thr:SetScript("OnEnterPressed", function(self) applyThreshold(); self:ClearFocus() end)
    r.thr:SetScript("OnEditFocusLost", applyThreshold)
    r.thr:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    r.thr:SetScript("OnEnter", function(self) tooltip(self, "Alert when you have this many or fewer in your bags.") end)
    r.thr:SetScript("OnLeave", function() GameTooltip:Hide() end)

    r.on:SetScript("OnClick", function(self)
        if r.st then r.st.enabled = self:GetChecked() and true or false; C.markDirty() end
    end)
    r.miss:SetScript("OnClick", function(self)
        if r.st then r.st.missing = self:GetChecked() and true or false; C.markDirty() end
    end)
    r.miss:SetScript("OnEnter", function(self) tooltip(self, "Also alert when you have none left in your bags.") end)
    r.miss:SetScript("OnLeave", function() GameTooltip:Hide() end)
    r.del:SetScript("OnClick", function() if r.onRemove then r.onRemove() end end)

    function r:Refresh()
        local st = self.st
        if not st then return end
        self.on:SetChecked(st.enabled ~= false)
        self.miss:SetChecked(st.missing ~= false)
        if not self.thr:HasFocus() then self.thr:SetText(tostring(st.threshold or 0)) end
        local n = self.countFn and self.countFn() or 0
        self.count:SetText(tostring(n))
        if n <= (st.threshold or 0) then self.count:SetTextColor(1, 0.45, 0.2) else self.count:SetTextColor(0.5, 1, 0.5) end
    end

    function r:Bind(st, name, icon, countFn, onRemove)
        self.st, self.countFn, self.onRemove = st, countFn, onRemove
        self.icon:SetTexture(icon or QMARK)
        self.label:SetText(name or "")
        self.del:SetShown(onRemove ~= nil)
        self:Refresh()
    end

    return r
end

function ns.RebuildStock()
    if not frame or not ss then return end
    for _, r in ipairs(stockRows) do r:Hide() end
    for i, it in ipairs(DB.stockItems) do
        local r = stockRows[i]
        if not r then r = makeStockRow(ss); stockRows[i] = r end
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", ss, "TOPLEFT", 0, stockListY - (i - 1) * 26)
        local item = it
        r:Bind(item, S.ItemName(item), itemIcon(item.id), function() return S.ItemCount(item.id) end, function()
            for k, v in ipairs(DB.stockItems) do
                if v == item then table.remove(DB.stockItems, k); break end
            end
            ns.RebuildStock()
            C.markDirty()
        end)
        r:Show()
    end
    ns.Relayout()
end

-- keep both dynamic sections and the scroll height in step
function ns.Relayout()
    if not frame or not ss or not cs then return end
    ss:SetHeight(ssStaticH + #DB.stockItems * 26)
    cs:SetHeight(csStaticH + #DB.custom * 26)
    child:SetHeight(-ssBaseY + ss:GetHeight() + cs:GetHeight() + 40)
    C_Timer.After(0.05, updateScroll)
end

--------------------------------------------------------------------------
-- build the window
--------------------------------------------------------------------------
local function build()
    frame = CreateFrame("Frame", "EasyBuffConfig", UIParent, "BackdropTemplate")
    frame:SetSize(430, 580)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("DIALOG")
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:SetClampedToScreen(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    frame:SetBackdropColor(0.07, 0.07, 0.09, 0.96)
    frame:SetBackdropBorderColor(0.4, 0.35, 0.15, 1)
    tinsert(UISpecialFrames, "EasyBuffConfig")

    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 14, -12)
    title:SetText("EasyBuff")

    local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -2, -2)

    local hint = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    hint:SetPoint("TOPRIGHT", close, "TOPLEFT", -6, -10)
    hint:SetText("drag to move - wheel to scroll")

    -- scroll area
    sf = CreateFrame("ScrollFrame", nil, frame)
    sf:SetPoint("TOPLEFT", 12, -40)
    sf:SetPoint("BOTTOMRIGHT", -26, 12)
    child = CreateFrame("Frame", nil, sf)
    child:SetSize(392, 10)
    sf:SetScrollChild(child)
    sf:EnableMouseWheel(true)
    sf:SetScript("OnMouseWheel", function(self, delta)
        local max = self:GetVerticalScrollRange() or 0
        self:SetVerticalScroll(math.max(0, math.min(max, self:GetVerticalScroll() - delta * 48)))
    end)

    bar = CreateFrame("Slider", nil, frame)
    bar:SetOrientation("VERTICAL")
    bar:SetPoint("TOPRIGHT", -10, -40)
    bar:SetPoint("BOTTOMRIGHT", -10, 12)
    bar:SetWidth(8)
    local track = bar:CreateTexture(nil, "BACKGROUND")
    track:SetAllPoints()
    track:SetColorTexture(1, 1, 1, 0.08)
    bar:SetThumbTexture("Interface\\Buttons\\WHITE8x8")
    local thumb = bar:GetThumbTexture()
    thumb:SetSize(8, 40)
    thumb:SetVertexColor(0.85, 0.7, 0.2, 0.9)
    bar:SetMinMaxValues(0, 1)
    bar:SetValue(0)
    bar:SetScript("OnValueChanged", function(_, v) sf:SetVerticalScroll(v) end)
    sf:SetScript("OnVerticalScroll", function(_, off) bar:SetValue(off) end)

    ------------------------------------------------------------------
    local y = -4
    local col = 0

    local function header(text)
        if col ~= 0 then col = 0; y = y - 26 end
        y = y - 6
        local fs = child:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        fs:SetPoint("TOPLEFT", 4, y)
        fs:SetText(text)
        y = y - 22
    end

    local function note(text)
        local fs = child:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        fs:SetPoint("TOPLEFT", 4, y)
        fs:SetWidth(380)
        fs:SetJustifyH("LEFT")
        fs:SetText(text)
        y = y - (fs:GetStringHeight() + 6)
    end

    local function grid(label, get, set, tip)
        makeCheck(child, label, 4 + col * COLW, y, get, set, tip)
        col = col + 1
        if col == 2 then col = 0; y = y - 26 end
    end

    local function endGrid() if col ~= 0 then col = 0; y = y - 26 end end

    local function stepper(label, get, set, step, minv, maxv, fmt)
        local fs = child:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        fs:SetPoint("TOPLEFT", 4, y - 5)
        fs:SetText(label)
        local val = child:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        val:SetPoint("TOPLEFT", 200, y - 5)
        val:SetWidth(40)
        val:SetJustifyH("CENTER")
        local function show() val:SetText(string.format(fmt, get())) end
        local function bump(d)
            local v = math.floor((get() + d * step) * 100 + 0.5) / 100
            v = math.max(minv, math.min(maxv, v))
            set(v)
            show()
        end
        makeButton(child, "-", 160, y, 28, function() bump(-1) end)
        makeButton(child, "+", 252, y, 28, function() bump(1) end)
        refreshers[#refreshers + 1] = show
        show()
        y = y - 28
    end

    local function simpleKey(key) return function() return DB.ignore[key] ~= true end end
    local function keySet(key) return function(v) if v then DB.ignore[key] = false else DB.ignore[key] = true end end end

    local function buffGet(def)
        return function()
            local ig = DB.ignore[def.key]
            if ig == true then return false end
            if def.off and ig ~= false then return false end
            return true
        end
    end

    local function providerText(def)
        local loc = LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[def.provider] or def.provider
        return loc
    end

    ------------------------------------------------------------------
    header("General")
    local function opt(label, field, tip)
        grid(label, function() return DB[field] end, function(v) DB[field] = v end, tip)
    end
    opt("Addon enabled", "enabled")
    opt("Flashing icons", "flash")
    opt("Hide while mounted", "hideMounted")
    opt("Group buff reminders", "group", "Remind about buffs other classes in your party/raid can give you.")
    opt("Consumable reminders", "consumes", "Food, elixirs, weapon enchants and the raid checklist.")
    opt("Consumables in group only", "consumesGroupOnly", "On: food, elixir/flask and weapon buff reminders only show while you are in a party or raid. Turn off to see them when solo too.")
    opt("Full raid checklist", "raid", "In a raid group: flasks, specific elixirs, scrolls, Deviate Delight, Zanza, Juju and Blasted Lands buffs.")
    grid("Hide minimap icon", function() return DB.hideMinimap end, function(v)
        DB.hideMinimap = v
        if minimapBtn then minimapBtn:SetShown(not v) end
    end, "You can still open settings with /easybuff")
    endGrid()

    stepper("Icon scale", function() return DB.scale or 1 end, function(v) C.slash("scale " .. v) end, 0.1, 0.5, 3, "%.1f")
    stepper("Icons per row", function() return DB.perRow or 8 end, function(v) DB.perRow = v; C.markDirty() end, 1, 1, 20, "%d")

    makeButton(child, "Unlock position", 4, y, 120, function() C.slash("unlock") end)
    makeButton(child, "Lock position", 130, y, 110, function() C.slash("lock") end)
    makeButton(child, "Test icons", 246, y, 100, function() C.slash("test") end)
    y = y - 30

    ------------------------------------------------------------------
    local classLoc = UnitClass("player")
    header("Your buffs (" .. tostring(classLoc) .. ")")
    local mine = D.selfBuffs[playerClass] or {}
    if #mine == 0 then
        note("No self buffs for this class. Weapon poisons are under Consumables.")
    else
        for _, def in ipairs(mine) do
            grid(def.label, buffGet(def), keySet(def.key), "Self buff - only shown if you know the spell.")
        end
        endGrid()
    end

    header("Buffs from other classes in your group")
    for _, def in ipairs(D.groupBuffs) do
        if def.provider ~= playerClass then
            grid(def.label, buffGet(def), keySet(def.key), "Cast by: " .. providerText(def) .. " (shown only when one is in your group)")
        end
    end
    endGrid()

    header("Consumables")
    grid("Food", simpleKey("FOOD"), keySet("FOOD"), "Any 'Well Fed' style food buff.")
    grid("Flask / elixir", simpleKey("ELIXIR"), keySet("ELIXIR"), "Outside raids: one reminder if you have no flask or class elixir.")
    if D.weapon[playerClass] then
        grid("Weapon: main hand", simpleKey("WEAPON_MH"), keySet("WEAPON_MH"), D.weapon[playerClass].suggest)
        grid("Weapon: off hand", simpleKey("WEAPON_OH"), keySet("WEAPON_OH"), D.weapon[playerClass].suggest)
    end
    if D.pet[playerClass] then
        grid("Pet", simpleKey("PET"), keySet("PET"), "Remind when you have no pet out.")
    end
    endGrid()

    header("Raid consumables")
    local function relevant(e)
        return e.off or e.classes == nil or listHas(e.classes, playerClass) or listHas(e.opt, playerClass)
    end
    local function raidItem(e)
        grid(e.label, function() return C.entryActive(e) end, keySet(e.key), e.suggest)
    end
    raidItem(D.raid.flask)
    for _, e in ipairs(D.raid.elixirs) do if relevant(e) then raidItem(e) end end
    for _, e in ipairs(D.raid.other) do if relevant(e) then raidItem(e) end end
    endGrid()

    ------------------------------------------------------------------
    -- Two stacked sections whose lists grow: stock alerts (ss), then custom buffs (cs)
    ssBaseY = y
    ss = CreateFrame("Frame", nil, child)
    ss:SetPoint("TOPLEFT", child, "TOPLEFT", 0, ssBaseY)
    ss:SetSize(392, 10)
    cs = CreateFrame("Frame", nil, child)
    cs:SetPoint("TOPLEFT", ss, "BOTTOMLEFT", 0, -6)
    cs:SetSize(392, 10)

    local function title(parent, yy, text)
        local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        fs:SetPoint("TOPLEFT", parent, "TOPLEFT", 4, yy)
        fs:SetText(text)
    end
    local function paragraph(parent, yy, text)
        local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        fs:SetPoint("TOPLEFT", parent, "TOPLEFT", 4, yy)
        fs:SetWidth(380)
        fs:SetJustifyH("LEFT")
        fs:SetText(text)
        return fs
    end
    local function entryBox(parent, yy, onEnter)
        local box = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
        box:SetSize(270, 22)
        box:SetPoint("TOPLEFT", parent, "TOPLEFT", 10, yy)
        box:SetAutoFocus(false)
        box:SetMaxLetters(512)
        box:SetFontObject("ChatFontNormal")
        box:SetScript("OnEnterPressed", function() onEnter() end)
        box:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        makeButton(parent, "Add", 290, yy + 1, 60, onEnter)
        return box
    end

    ------------------------------------------------------------------
    -- Stock alerts
    local y1 = -6
    title(ss, y1, "Stock alerts (running low)")
    y1 = y1 - 22
    makeCheck(ss, "Stock alerts enabled", 4, y1, function() return DB.stock end, function(v) DB.stock = v end,
        "Show an orange reminder when a consumable in your bags is running low or gone.")
    y1 = y1 - 26
    paragraph(ss, y1, "Alerts when you have the chosen number or fewer in your bags. \"At 0\" also alerts when none are left (built-in categories only after you have carried some).")
    y1 = y1 - 32

    local function colhead(x, text)
        local fs = ss:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        fs:SetPoint("TOPLEFT", ss, "TOPLEFT", x, y1)
        fs:SetText(text)
    end
    colhead(168, "Alert at")
    colhead(226, "At 0")
    colhead(284, "In bags")
    y1 = y1 - 16

    for _, cat in ipairs(S.CATS) do
        if not cat.classes or listHas(cat.classes, playerClass) then
            local row = makeStockRow(ss)
            row:SetPoint("TOPLEFT", ss, "TOPLEFT", 0, y1)
            row:Bind(DB.stockCats[cat.key], cat.label, itemIcon(cat.iconItem), function() return S.CategoryCount(cat.key) end, nil)
            refreshers[#refreshers + 1] = function() row:Refresh() end
            y1 = y1 - 26
        end
    end

    y1 = y1 - 6
    paragraph(ss, y1, "Track another item: type its item ID or name, or shift-click it (bags or chat) while the box below has focus, then press Add.")
    y1 = y1 - 32
    stockInput = entryBox(ss, y1, addStockItem)
    y1 = y1 - 28
    stockFeedback = ss:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    stockFeedback:SetPoint("TOPLEFT", ss, "TOPLEFT", 4, y1)
    stockFeedback:SetWidth(380)
    stockFeedback:SetJustifyH("LEFT")
    y1 = y1 - 22
    stockListY = y1
    ssStaticH = -y1

    ------------------------------------------------------------------
    -- Custom buffs
    local y2 = -6
    title(cs, y2, "Custom buffs")
    y2 = y2 - 22
    paragraph(cs, y2, "Paste a spell ID or name, or shift-click a spell (chat or spellbook) or an item while the box below has focus, then press Add.")
    y2 = y2 - 32
    input = entryBox(cs, y2, addCustom)
    y2 = y2 - 28
    feedback = cs:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    feedback:SetPoint("TOPLEFT", cs, "TOPLEFT", 4, y2)
    feedback:SetWidth(380)
    feedback:SetJustifyH("LEFT")
    y2 = y2 - 22
    customListY = y2
    csStaticH = -y2

    if type(ChatEdit_InsertLink) == "function" then hooksecurefunc("ChatEdit_InsertLink", onInsertLink) end
    if ChatFrameUtil and type(ChatFrameUtil.InsertLink) == "function" then
        hooksecurefunc(ChatFrameUtil, "InsertLink", onInsertLink)
    end

    frame:SetScript("OnShow", function()
        for _, f in ipairs(refreshers) do f() end
        ns.RebuildCustom()
        ns.RebuildStock()
    end)
    frame:Hide()
    ns.RebuildCustom()
    ns.RebuildStock()
end

--------------------------------------------------------------------------
-- public
--------------------------------------------------------------------------
function ns.ToggleConfig()
    if not frame then build() end
    frame:SetShown(not frame:IsShown())
end

function ns.InitConfig()
    C = ns.core
    DB = C.getDB()
    playerClass = C.playerClass()
    S = ns.Stock
    if S then S.Ensure(DB) end
    if not DB.custom then DB.custom = {} end
    createMinimapButton()
end
