--[[
  EasyBuff - Core.lua
  Flashing icons above your character for missing buffs / consumables.
  Works on the Mainline-style API used by WoW: Forever (Midnight aura restrictions):
  auras are only evaluated OUT OF COMBAT and any "secret" value aborts the scan.
]]

local ADDON, ns = ...
local D = ns.Data

local DEFAULTS = {
    enabled = true, consumes = true, group = true, flash = true, hideMounted = true,
    raid = true, perRow = 8, consumesGroupOnly = true, custom = {}, minimapAngle = 215, hideMinimap = false,
    point = "CENTER", x = 0, y = 170, scale = 1.0,
    ignore = {},
}

local DB, playerClass
local container, iconFrames = nil, {}
local ICON, GAP = 44, 16
local dirty, elapsed = true, 0
local unlocked, testing = false, false
local nameCache = {}

--------------------------------------------------------------------------
-- helpers
--------------------------------------------------------------------------
local function say(msg) print("|cff33ff99EasyBuff|r: " .. tostring(msg)) end

local function isSecret(v) return issecretvalue and issecretvalue(v) or false end

local function spellName(id)
    if C_Spell and C_Spell.GetSpellName then return C_Spell.GetSpellName(id) end
    return (GetSpellInfo and GetSpellInfo(id)) or nil
end

local function spellTex(id)
    if C_Spell and C_Spell.GetSpellTexture then return C_Spell.GetSpellTexture(id) end
    return GetSpellTexture and GetSpellTexture(id) or nil
end

local function itemTex(id)
    if C_Item and C_Item.GetItemIconByID then return C_Item.GetItemIconByID(id) end
    return GetItemIcon and GetItemIcon(id) or nil
end

-- Spellbook lookups are cached: they were being repeated (dozens of API calls) every
-- time the reminders refreshed. The cache is wiped whenever the spellbook can change.
local knownCache, knownNameCache, knowsDefCache = {}, {}, {}

local function wipeKnownCache()
    wipe(knownCache); wipe(knownNameCache); wipe(knowsDefCache)
end

local function knownRaw(id)
    if C_SpellBook and C_SpellBook.IsSpellKnown and C_SpellBook.IsSpellKnown(id) then return true end
    if IsPlayerSpell and IsPlayerSpell(id) then return true end
    if IsSpellKnown and IsSpellKnown(id) then return true end
    return false
end

local function known(id)
    local c = knownCache[id]
    if c ~= nil then return c end
    local ok, r = pcall(knownRaw, id)
    c = (ok and r) and true or false
    knownCache[id] = c
    return c
end

local function knowsAny(ids)
    for _, id in ipairs(ids) do if known(id) then return true end end
    return false
end

local function knownByNameRaw(name)
    local info = C_Spell and C_Spell.GetSpellInfo and C_Spell.GetSpellInfo(name)
    if type(info) == "table" and info.spellID then return known(info.spellID) end
    return false
end

local function knownByName(name)
    local c = knownNameCache[name]
    if c ~= nil then return c end
    local ok, r = pcall(knownByNameRaw, name)
    c = (ok and r) and true or false
    knownNameCache[name] = c
    return c
end

-- a buff is "learned" if any rank ID or any English name is in the spellbook
local function knowsDef(def)
    local c = knowsDefCache[def]
    if c ~= nil then return c end
    c = knowsAny(def.ids)
    if not c and def.names then
        for _, n in ipairs(def.names) do if n and knownByName(n) then c = true; break end end
    end
    knowsDefCache[def] = c and true or false
    return knowsDefCache[def]
end

local function firstIcon(def)
    local ids = def.ids
    for i = #ids, 1, -1 do               -- highest rank first
        local t = spellTex(ids[i])
        if t then return t end
    end
    if def.names then
        for _, n in ipairs(def.names) do
            local ok, t = pcall(spellTex, n)
            if ok and t then return t end
        end
    end
    return "Interface\\Icons\\INV_Misc_QuestionMark"
end

local function inList(list, v)
    if not list then return true end
    for _, c in ipairs(list) do if c == v then return true end end
    return false
end

--------------------------------------------------------------------------
-- aura scan
--------------------------------------------------------------------------
-- returns idSet, nameSet, blob, sawSecret
--   idSet   [spellID] = true
--   nameSet [aura name] = true            (exact matching)
--   blob    all aura names joined by "\n"  (one string.find per pattern instead of one per aura)
local function scanPlayerAuras()
    local ids, set, list, secret = {}, {}, {}, false
    for i = 1, 120 do
        local a = C_UnitAuras.GetAuraDataByIndex("player", i, "HELPFUL")
        if not a then break end
        local sid, nm = a.spellId, a.name
        if isSecret(sid) or isSecret(nm) then secret = true
        else
            if sid then ids[sid] = true end
            if nm then set[nm] = true; list[#list + 1] = nm end
        end
    end
    return ids, set, table.concat(list, "\n"), secret
end

local function buffNames(def)
    if nameCache[def.key] then return nameCache[def.key] end
    local set, n = {}, 0
    for _, id in ipairs(def.ids) do
        local nm = spellName(id)
        if nm then set[nm] = true; n = n + 1 end
    end
    if n > 0 then nameCache[def.key] = set end   -- only cache when data was loaded
    return set
end

local function hasBuff(def, idSet, nameSet)
    for _, id in ipairs(def.ids) do if idSet[id] then return true end end
    for nm in pairs(buffNames(def)) do if nameSet[nm] then return true end end
    if def.names then
        for _, want in ipairs(def.names) do if want and nameSet[want] then return true end end
    end
    return false
end

-- plain-text substring match of any pattern against the joined aura names
local function hasPattern(patterns, blob)
    for _, p in ipairs(patterns) do
        if string.find(blob, p, 1, true) then return true end
    end
    return false
end

--------------------------------------------------------------------------
-- group
--------------------------------------------------------------------------
-- Which classes are in your group. Up to 40 raid members x 5 API calls, so the result
-- is cached: rebuilt on roster changes and at most every 5 seconds otherwise (the
-- periodic rebuild picks up members going offline / dying).
local groupCache, groupCacheT, rosterDirty = {}, -100, true

local function groupClasses()
    local now = GetTime()
    if not rosterDirty and now - groupCacheT < 5 then return groupCache end
    rosterDirty, groupCacheT = false, now

    local set = {}
    if IsInGroup() then
        local raid = IsInRaid()
        local prefix = raid and "raid" or "party"
        local n = raid and GetNumGroupMembers() or (GetNumGroupMembers() - 1)
        for i = 1, n do
            local unit = prefix .. i
            if UnitExists(unit) and not UnitIsUnit(unit, "player")
               and UnitIsConnected(unit) and not UnitIsDeadOrGhost(unit) then
                local _, token = UnitClass(unit)
                if token and not isSecret(token) then set[token] = true end
            end
        end
    end
    groupCache = set
    return set
end

--------------------------------------------------------------------------
-- evaluation -> list of reminders
--------------------------------------------------------------------------
local function add(list, key, icon, label, sub, tip, extra)
    if DB.ignore[key] then return end
    local r = { key = key, icon = icon, label = label, sub = sub, tip = tip }
    if extra then r.color = extra.color; r.count = extra.count; r.action = extra.action end
    list[#list + 1] = r
end

-- raid checklist helpers ------------------------------------------------
local QMARK = "Interface\\Icons\\INV_Misc_QuestionMark"

local function entryActive(e)
    local ig = DB.ignore[e.key]
    if ig == true then return false end
    if e.off and ig ~= false then return false end
    if e.classes == nil or inList(e.classes, playerClass) then return true end
    if e.opt and inList(e.opt, playerClass) and ig == false then return true end
    return false
end

local function entryMatch(e, idSet, nameSet, blob)
    if e.ids then for _, id in ipairs(e.ids) do if idSet[id] then return true end end end
    if e.exact then
        for _, w in ipairs(e.exact) do if nameSet[w] then return true end end
    end
    if e.patterns and hasPattern(e.patterns, blob) then return true end
    return false
end

local function entryIcon(e)
    return (e.iconItem and itemTex(e.iconItem)) or QMARK
end

local function weaponItemIsWeapon(slot)
    local id = GetInventoryItemID("player", slot)
    if not id then return false end
    local classID = select(6, C_Item.GetItemInfoInstant(id))
    return classID == 2
end

-- click actions (icons are secure buttons; attributes are only set out of combat)
local function spellAction(name)
    if name then return { type = "spell", spell = name, unit = "player" } end
end

-- /use item:ID  (+ optional equipment slot, for poisons / stones / oils)
local function useAction(itemID, slot)
    if not itemID then return nil end
    local m = "/use item:" .. itemID
    if slot then m = m .. "\n/use " .. slot end
    return { type = "macro", macrotext = m }
end

local function haveItem(id)
    return id and (C_Item.GetItemCount(id, false) or 0) > 0
end

-- best spell name to cast for a buff definition: explicit def.cast order, then def.names, then highest known rank
local function castName(def)
    if def.cast then
        for _, n in ipairs(def.cast) do if knownByName(n) then return n end end
    end
    if def.names then
        for _, n in ipairs(def.names) do if n and knownByName(n) then return n end end
    end
    if def.ids then
        for i = #def.ids, 1, -1 do
            if known(def.ids[i]) then
                local n = spellName(def.ids[i])
                if n then return n end
            end
        end
    end
    return nil
end

local function evaluate()
    local list = {}
    local ids, names, blob, secret = scanPlayerAuras()
    if secret then return nil end

    -- 1) self buffs of this class
    local selfKeys = {}
    for _, def in ipairs(D.selfBuffs[playerClass] or {}) do
        selfKeys[def.key] = true
        local off = def.off and DB.ignore[def.key] ~= false
        if not off and knowsDef(def) and not hasBuff(def, ids, names) then
            add(list, def.key, firstIcon(def), def.label, nil, "Missing: " .. def.label,
                { action = spellAction(castName(def)) })
        end
    end

    -- 2) pet
    local pet = D.pet[playerClass]
    if pet and known(pet.spell) and not UnitExists("pet") then
        add(list, "PET", pet.icon, pet.label, nil, "No pet - " .. pet.suggest,
            { action = (playerClass == "HUNTER") and spellAction(spellName(pet.spell)) or nil })
    end

    -- 3) buffs other classes in the group can give us
    if DB.group then
        local classes = groupClasses()
        for _, def in ipairs(D.groupBuffs) do
            local off = def.off and DB.ignore[def.key] ~= false
            if not off and classes[def.provider] and def.provider ~= playerClass
               and not selfKeys[def.key] and inList(def.classes, playerClass)
               and not hasBuff(def, ids, names) then
                local cls = LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[def.provider] or def.provider
                add(list, def.key, firstIcon(def), def.label, "ask " .. cls,
                    "Missing " .. def.label .. " - a " .. cls .. " in your group can cast it")
            end
        end
    end

    -- 3b) custom buffs added in the settings window
    -- (skipped when one of your class's built-in buffs already covers that spell, so you never get two icons)
    local covered = {}
    for _, def in ipairs(D.selfBuffs[playerClass] or {}) do
        for _, id in ipairs(def.ids) do covered[id] = true end
    end
    for _, c in ipairs(DB.custom or {}) do
        if c.enabled ~= false and c.id and not covered[c.id] and (not c.requireKnown or known(c.id)) then
            local cdef = { key = "CUSTOM" .. c.id, ids = { c.id }, names = { c.name } }
            if not hasBuff(cdef, ids, names) then
                add(list, cdef.key, spellTex(c.id) or QMARK, c.name or tostring(c.id), nil,
                    "Missing: " .. (c.name or c.id) .. " (custom)",
                    { action = known(c.id) and spellAction(spellName(c.id)) or nil })
            end
        end
    end

    -- 4) consumables (food, elixir/flask, weapon buffs, raid checklist);
    --    by default only while in a group - see DB.consumesGroupOnly
    if DB.consumes and (not DB.consumesGroupOnly or IsInGroup()) then
        local raid = DB.raid and IsInRaid()
        local f = D.food
        if not hasPattern(f.patterns, blob) then
            add(list, f.key, itemTex(f.iconItem) or "Interface\\Icons\\INV_Misc_QuestionMark",
                f.label, nil, "No food buff. Try: " .. (f.suggest[playerClass] or "any food"),
                { action = ns.Stock and useAction(ns.Stock.BestItem("FOOD")) or nil })
        end

        local e = D.elixir
        local pats = e.patterns[playerClass]
        if not raid and pats and not hasPattern(pats, blob) then
            add(list, e.key, itemTex(e.iconItem) or "Interface\\Icons\\INV_Misc_QuestionMark",
                e.label, nil, "No flask/elixir. Try: " .. (e.suggest[playerClass] or ""),
                { action = ns.Stock and useAction(ns.Stock.BestItem("FLASK") or ns.Stock.BestItem("ELIXIR")) or nil })
        end

        local z = D.zanza
        if z and not raid and not (z.off and DB.ignore[z.key] ~= false) and not hasPattern(z.patterns, blob) then
            add(list, z.key, itemTex(z.iconItem) or "Interface\\Icons\\INV_Misc_QuestionMark",
                z.label, nil, "No Zanza buff. Try: " .. z.suggest,
                { action = haveItem(z.iconItem) and useAction(z.iconItem) or nil })
        end

        -- full raid checklist: flask OR specific elixirs, scrolls, Deviate Delight, Zanza, Juju, Blasted Lands
        if raid then
            local R = D.raid
            if not hasPattern(R.flask.patterns, blob) then
                local anyElixir, missing = false, {}
                for _, e in ipairs(R.elixirs) do
                    if entryActive(e) then
                        if entryMatch(e, ids, names, blob) then anyElixir = true else missing[#missing + 1] = e end
                    end
                end
                if not anyElixir and not DB.ignore[R.flask.key] then
                    add(list, R.flask.key, entryIcon(R.flask), R.flask.label, nil, "No flask. Try: " .. R.flask.suggest,
                        { action = ns.Stock and useAction(ns.Stock.BestItem("FLASK")) or nil })
                end
                for _, e in ipairs(missing) do
                    add(list, e.key, entryIcon(e), e.label, nil, "Missing " .. (e.suggest or e.label),
                        { action = haveItem(e.iconItem) and useAction(e.iconItem) or nil })
                end
            end
            for _, e in ipairs(R.other) do
                if entryActive(e) and not entryMatch(e, ids, names, blob) then
                    add(list, e.key, entryIcon(e), e.label, nil, "Missing " .. (e.suggest or e.label),
                        { action = haveItem(e.iconItem) and useAction(e.iconItem) or nil })
                end
            end
        end

        local w = D.weapon[playerClass]
        if w and (not w.needSpell or known(w.needSpell)) then
            local hasMH, _, _, _, hasOH = GetWeaponEnchantInfo()
            local icon = (w.iconSpell and spellTex(w.iconSpell)) or (w.iconItem and itemTex(w.iconItem))
                         or "Interface\\Icons\\INV_Misc_QuestionMark"
            -- what to apply: Shaman casts an imbue; others use a poison/stone/oil from the bags
            local itemID = (w.itemPatterns and ns.Stock) and ns.Stock.FindByNames(w.itemPatterns) or nil
            local imbue = w.cast and castName({ cast = w.cast }) or nil
            if weaponItemIsWeapon(16) and not hasMH then
                add(list, "WEAPON_MH", icon, w.kind, "main hand", "Main hand: " .. w.suggest,
                    { action = imbue and spellAction(imbue) or useAction(itemID, 16) })
            end
            if weaponItemIsWeapon(17) and not hasOH then
                add(list, "WEAPON_OH", icon, w.kind, "off hand", "Off hand: " .. w.suggest,
                    { action = useAction(itemID, 17) })
            end
        end
    end

    -- 5) low-supply alerts from your bags (see Stock.lua)
    if DB.stock and ns.Stock then
        local ok, found = pcall(ns.Stock.Evaluate, DB, playerClass)
        if ok and found then
            for _, r in ipairs(found) do add(list, r.key, r.icon, r.label, r.sub, r.tip, r) end
        end
    end

    return list
end

--------------------------------------------------------------------------
-- UI
--------------------------------------------------------------------------
local function savePosition()
    local p, _, rp, x, y = container:GetPoint()
    DB.point, DB.relPoint, DB.x, DB.y = p, rp, x, y
end

local function createContainer()
    -- Secure handler frame: the icons inside are secure (clickable) buttons, and ordinary
    -- code is not allowed to hide / move such frames in combat. The state driver below hides
    -- the whole group in combat for us, and every other change waits until combat ends.
    container = CreateFrame("Frame", "EasyBuffFrame", UIParent, "SecureHandlerStateTemplate,BackdropTemplate")
    RegisterStateDriver(container, "visibility", "[combat] hide; show")
    container:SetSize(ICON, ICON)
    container:SetFrameStrata("HIGH")
    container:SetMovable(true)
    container:SetClampedToScreen(true)
    container:RegisterForDrag("LeftButton")
    container:SetScript("OnDragStart", function(self) if unlocked then self:StartMoving() end end)
    container:SetScript("OnDragStop", function(self) self:StopMovingOrSizing(); savePosition() end)

    container.hint = container:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    container.hint:SetPoint("BOTTOM", container, "TOP", 0, 6)
    container.hint:SetText("EasyBuff - drag me, then /easybuff lock")
    container.hint:Hide()
end

local pendingPosition = false

local function applyPosition()
    if InCombatLockdown() then pendingPosition = true; return false end    -- redone after combat
    pendingPosition = false
    container:ClearAllPoints()
    container:SetPoint(DB.point, UIParent, DB.relPoint or DB.point, DB.x, DB.y)
    container:SetScale(DB.scale)
    return true
end

local function makeIcon(i)
    local f = CreateFrame("Button", nil, container, "SecureActionButtonTemplate,BackdropTemplate")
    f:RegisterForClicks("AnyUp", "AnyDown")
    f:SetSize(ICON, ICON)
    f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 2 })
    f:SetBackdropColor(0, 0, 0, 0.75)
    f:SetBackdropBorderColor(1, 0.1, 0.1, 1)

    f.tex = f:CreateTexture(nil, "ARTWORK")
    f.tex:SetPoint("TOPLEFT", 2, -2)
    f.tex:SetPoint("BOTTOMRIGHT", -2, 2)
    f.tex:SetTexCoord(0.07, 0.93, 0.07, 0.93)

    f.count = f:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
    f.count:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -3, 3)

    f.label = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    f.label:SetPoint("TOP", f, "BOTTOM", 0, -3)
    f.label:SetWidth(ICON + GAP - 2)
    f.label:SetJustifyH("CENTER")
    f.label:SetJustifyV("TOP")
    f.label:SetWordWrap(true)
    f.label:SetMaxLines(3)
    f.label:SetSpacing(1)

    f.ag = f:CreateAnimationGroup()
    f.ag:SetLooping("BOUNCE")
    local a = f.ag:CreateAnimation("Alpha")
    a:SetFromAlpha(1); a:SetToAlpha(0.25); a:SetDuration(0.55); a:SetSmoothing("IN_OUT")

    f:EnableMouse(true)
    f:SetScript("OnEnter", function(self)
        if self.tip then
            GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
            GameTooltip:SetText(self.tip, 1, 1, 1, 1, true)
            if self.hasAction then GameTooltip:AddLine("Click to use", 0.4, 1, 0.4) end
            GameTooltip:Show()
        end
    end)
    f:SetScript("OnLeave", function() GameTooltip:Hide() end)

    iconFrames[i] = f
    return f
end

-- icons are secure buttons: attributes / show / hide / move are blocked in combat
local function setAction(f, a)
    f:SetAttribute("type", a and a.type or nil)
    f:SetAttribute("spell", a and a.spell or nil)
    f:SetAttribute("unit", a and a.unit or nil)
    f:SetAttribute("macrotext", a and a.macrotext or nil)
    f.hasAction = a ~= nil
end

-- Cheap fingerprint of what is on screen. When nothing changed we skip the redraw, which
-- also stops the flash animation from being restarted on every refresh.
local lastSig

local function signature(list)
    if not list or #list == 0 then return unlocked and "empty-unlocked" or "empty" end
    local parts = { tostring(DB.perRow or 8), DB.flash and "f" or "n" }
    for i = 1, #list do
        local r = list[i]
        local act = r.action and (r.action.spell or r.action.macrotext) or ""
        parts[#parts + 1] = table.concat({ tostring(r.key), tostring(r.icon), tostring(r.label),
                                           tostring(r.sub), tostring(r.count), act, tostring(r.tip) }, "|")
    end
    return table.concat(parts, "\n")
end

local function render(list)
    -- In combat the visibility driver hides the group and secure buttons cannot be changed;
    -- the next refresh after combat ends (PLAYER_REGEN_ENABLED) redraws.
    if InCombatLockdown() then return end

    local sig = signature(list)
    if sig == lastSig then return end
    lastSig = sig

    if not (testing or unlocked) then
        ns.activeCount = list and #list or 0
        if ns.OnCount then ns.OnCount(ns.activeCount) end
    end
    if not list or #list == 0 then
        for _, f in ipairs(iconFrames) do f.ag:Stop(); f:Hide() end
        if not unlocked then container:Hide() end
        return
    end
    container:Show()
    local perRow = math.max(1, DB.perRow or 8)
    local cols = math.min(#list, perRow)
    local rows = math.ceil(#list / perRow)
    local ROWH = ICON + 48                      -- icon + up to 3 lines of text
    container:SetSize(cols * ICON + (cols - 1) * GAP, ICON + (rows - 1) * ROWH)
    for i, r in ipairs(list) do
        local f = iconFrames[i] or makeIcon(i)
        local col, row = (i - 1) % perRow, math.floor((i - 1) / perRow)
        f:ClearAllPoints()
        f:SetPoint("TOPLEFT", container, "TOPLEFT", col * (ICON + GAP), -row * ROWH)
        f.tex:SetTexture(r.icon)
        local bc = r.color or { 1, 0.1, 0.1, 1 }
        f:SetBackdropBorderColor(bc[1], bc[2], bc[3], bc[4] or 1)
        f.count:SetText(r.count and tostring(r.count) or "")
        local txt = "|cffffd933" .. (r.label or "") .. "|r"
        if r.sub and r.sub ~= "" then txt = txt .. "\n|cffffffff" .. r.sub .. "|r" end
        f.label:SetText(txt)
        f.tip = r.tip
        setAction(f, r.action)
        f:Show()
        if DB.flash then
            if not f.ag:IsPlaying() then f.ag:Play() end
        else
            f.ag:Stop(); f:SetAlpha(1)
        end
    end
    for i = #list + 1, #iconFrames do iconFrames[i].ag:Stop(); iconFrames[i]:Hide() end
end

local function sampleList()
    return {
        { icon = "Interface\\Icons\\Spell_Holy_WordFortitude", label = "Fortitude", tip = "Test icon" },
        { icon = "Interface\\Icons\\Spell_Holy_MagicalSentry", label = "Arcane Int", sub = "ask Mage", tip = "Test icon" },
        { icon = "Interface\\Icons\\INV_Misc_Food_15", label = "Food", tip = "Test icon" },
        { icon = "Interface\\Icons\\INV_Potion_27", label = "Elixir/Flask", tip = "Test icon" },
    }
end

--------------------------------------------------------------------------
-- update loop
--------------------------------------------------------------------------
local function shouldHide()
    if not DB.enabled then return true end
    if InCombatLockdown() or UnitAffectingCombat("player") then return true end
    if UnitIsDeadOrGhost("player") then return true end
    if DB.hideMounted and (IsMounted() or UnitOnTaxi("player")) then return true end
    if UnitInVehicle and UnitInVehicle("player") then return true end
    return false
end

local function update()
    dirty = false
    -- nothing to do in combat (the icons are hidden); PLAYER_REGEN_ENABLED marks us dirty again
    if InCombatLockdown() then return end
    if pendingPosition then applyPosition() end
    if testing or unlocked then render(sampleList()); return end
    if shouldHide() then render(nil); return end
    local list = evaluate()
    if list == nil then return end          -- secret values: keep the previous state
    render(list)
end

local function markDirty() dirty = true end

--------------------------------------------------------------------------
-- slash commands
--------------------------------------------------------------------------
local function onoff(v) return v and "|cff00ff00on|r" or "|cffff4040off|r" end

local function allKeys()
    local keys, seen = {}, {}
    local function add(k) if not seen[k] then seen[k] = true; keys[#keys + 1] = k end end
    for _, defs in pairs(D.selfBuffs) do for _, d in ipairs(defs) do add(d.key) end end
    for _, d in ipairs(D.groupBuffs) do add(d.key) end
    add(D.raid.flask.key)
    for _, e in ipairs(D.raid.elixirs) do add(e.key) end
    for _, e in ipairs(D.raid.other) do add(e.key) end
    add("FOOD"); add("ELIXIR"); add("ZANZA"); add("WEAPON_MH"); add("WEAPON_OH"); add("PET")
    table.sort(keys)
    return keys
end

local function handleSlash(msg)
    local cmd, arg = msg:match("^(%S*)%s*(.-)$")
    cmd = cmd:lower()
    if InCombatLockdown() and (cmd == "lock" or cmd == "unlock" or cmd == "scale") then
        say("can't change that during combat.")
        return
    end
    if cmd == "lock" then
        unlocked = false; container.hint:Hide(); container:EnableMouse(false); markDirty(); say("locked.")
    elseif cmd == "unlock" then
        unlocked = true; container.hint:Show(); container:EnableMouse(true); markDirty(); say("drag the icons, then /easybuff lock")
    elseif cmd == "test" then
        testing = not testing; markDirty(); say("test mode " .. onoff(testing))
    elseif cmd == "toggle" then
        DB.enabled = not DB.enabled; markDirty(); say("addon " .. onoff(DB.enabled))
    elseif cmd == "consumes" then
        DB.consumes = (arg ~= "off"); markDirty(); say("consumable reminders " .. onoff(DB.consumes))
    elseif cmd == "group" then
        DB.group = (arg ~= "off"); markDirty(); say("group buff reminders " .. onoff(DB.group))
    elseif cmd == "flash" then
        DB.flash = (arg ~= "off"); markDirty(); say("flashing " .. onoff(DB.flash))
    elseif cmd == "mounted" then
        DB.hideMounted = (arg ~= "off"); markDirty(); say("hide while mounted " .. onoff(DB.hideMounted))
    elseif cmd == "config" or cmd == "options" or cmd == "settings" or cmd == "" then
        if ns.ToggleConfig then ns.ToggleConfig() else say("settings window not loaded") end
    elseif cmd == "groupconsumes" then
        DB.consumesGroupOnly = (arg ~= "off"); markDirty()
        say("consumables only while in a group " .. onoff(DB.consumesGroupOnly))
    elseif cmd == "raid" then
        DB.raid = (arg ~= "off"); markDirty(); say("full raid consumable checklist " .. onoff(DB.raid))
    elseif cmd == "perrow" then
        local n = tonumber(arg)
        if n and n >= 1 and n <= 20 then DB.perRow = math.floor(n); markDirty(); say("icons per row " .. DB.perRow)
        else say("usage: /easybuff perrow 1-20") end
    elseif cmd == "scale" then
        local s = tonumber(arg)
        if s and s >= 0.5 and s <= 3 then DB.scale = s; applyPosition(); say("scale " .. s)
        else say("usage: /easybuff scale 0.5-3") end
    elseif cmd == "ignore" or cmd == "unignore" then
        local key = arg:upper()
        if key == "" then say("usage: /easybuff " .. cmd .. " KEY   (see /easybuff list)"); return end
        -- off-by-default buffs use ignore[key] == false to mean "force enabled"
        if cmd == "ignore" then DB.ignore[key] = true else DB.ignore[key] = false end
        markDirty(); say(key .. (cmd == "ignore" and " ignored." or " enabled."))
    elseif cmd == "list" then
        say("keys: " .. table.concat(allKeys(), ", "))
    elseif cmd == "debug" then
        local n = 0
        for i = 1, 120 do
            local a = C_UnitAuras.GetAuraDataByIndex("player", i, "HELPFUL")
            if not a then break end
            if isSecret(a.name) or isSecret(a.spellId) then say("aura data is secret right now (in combat?)"); return end
            say(string.format("%s  (spellID %s)", tostring(a.name), tostring(a.spellId))); n = n + 1
        end
        say(n .. " buffs. Class: " .. tostring(playerClass))
    else
        say("commands: config (or just /easybuff) | lock | unlock | test | toggle | consumes on/off | group on/off | flash on/off | mounted on/off | groupconsumes on/off | raid on/off | perrow N | scale N | ignore KEY | unignore KEY | list | debug")
    end
end

--------------------------------------------------------------------------
-- boot
--------------------------------------------------------------------------
local ev = CreateFrame("Frame")

-- These fire for every unit in the game (hundreds a second in a raid). Ask the client to
-- deliver them for the player only, instead of filtering them ourselves afterwards.
local PLAYER_ONLY = {
    UNIT_AURA = true, UNIT_PET = true, UNIT_INVENTORY_CHANGED = true,
    UNIT_ENTERED_VEHICLE = true, UNIT_EXITED_VEHICLE = true,
}
local function reg(e)
    if PLAYER_ONLY[e] then pcall(ev.RegisterUnitEvent, ev, e, "player")
    else pcall(ev.RegisterEvent, ev, e) end
end

ev:RegisterEvent("ADDON_LOADED")
ev:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" then
        if arg1 ~= ADDON then return end
        EasyBuffDB = EasyBuffDB or {}
        DB = EasyBuffDB
        for k, v in pairs(DEFAULTS) do if DB[k] == nil then DB[k] = (type(v) == "table") and {} or v end end
        if ns.Stock then ns.Stock.Ensure(DB) end
        playerClass = select(2, UnitClass("player"))

        createContainer()
        applyPosition()
        container:Hide()

        SLASH_EASYBUFF1 = "/easybuff"
        SLASH_EASYBUFF2 = "/eb"
        SLASH_EASYBUFF3 = "/rebuff"
        SlashCmdList["EASYBUFF"] = handleSlash

        for _, e in ipairs({ "PLAYER_ENTERING_WORLD", "GROUP_ROSTER_UPDATE", "UNIT_AURA", "UNIT_PET",
                             "PLAYER_REGEN_ENABLED", "SPELLS_CHANGED",
                             "PLAYER_EQUIPMENT_CHANGED", "UNIT_INVENTORY_CHANGED", "PLAYER_DEAD",
                             "PLAYER_ALIVE", "PLAYER_UNGHOST", "PLAYER_MOUNT_DISPLAY_CHANGED",
                             "PLAYER_TALENT_UPDATE", "ACTIVE_TALENT_GROUP_CHANGED",
                             "UNIT_ENTERED_VEHICLE", "UNIT_EXITED_VEHICLE",
                             "BAG_UPDATE_DELAYED", "GET_ITEM_INFO_RECEIVED" }) do
            reg(e)
        end

        C_Timer.NewTicker(5, markDirty)   -- weapon enchants, item icons, range changes
        say("loaded for " .. tostring(playerClass) .. ". Click the minimap icon or type /easybuff for settings.")
        if ns.InitConfig then ns.InitConfig() end
    elseif event == "SPELLS_CHANGED" or event == "PLAYER_TALENT_UPDATE" or event == "ACTIVE_TALENT_GROUP_CHANGED" then
        wipeKnownCache()                         -- the spellbook may have changed
        dirty = true
    elseif event == "GROUP_ROSTER_UPDATE" then
        rosterDirty = true
        dirty = true
    elseif event == "PLAYER_ENTERING_WORLD" then
        wipeKnownCache()
        rosterDirty = true
        if ns.Stock then ns.Stock.Invalidate() end
        dirty = true
    elseif event == "BAG_UPDATE_DELAYED" or event == "GET_ITEM_INFO_RECEIVED" then
        if ns.Stock then ns.Stock.Invalidate() end   -- bag snapshot is rebuilt on next use
        dirty = true
    else
        -- aura / inventory / pet / vehicle (player only, see PLAYER_ONLY), combat end, death, mount ...
        dirty = true
    end
end)

-- shared with Config.lua
ns.core = {
    getDB = function() return DB end,
    playerClass = function() return playerClass end,
    markDirty = markDirty, known = known, spellName = spellName, spellTex = spellTex,
    entryActive = entryActive, slash = handleSlash, say = say,
}

ev:SetScript("OnUpdate", function(_, dt)
    elapsed = elapsed + dt
    if dirty and elapsed > 0.3 then
        elapsed = 0
        if container then update() end
    end
end)
