--[[
  EasyBuff - Data.lua
  All buff / consumable definitions live here so they are easy to edit.

  Buff definition fields
    key       unique id (used by /easybuff ignore <key>)
    label     short text under the icon
    ids       list of spell IDs (every rank, and the group version) that count as "buffed"
    names     (optional) English spell/buff names. Used as a fallback when an ID is wrong:
              matches the aura name, finds the spell in your spellbook and fetches its icon
    provider  class token that casts it (used for group buffs)
    classes   (optional) only remind these receiving classes (group buffs)
    off       true = disabled by default (turn on with /easybuff unignore <key>)

  NOTE: Forever is a Vanilla-based game with new content. Spell IDs below are the
  Vanilla ones. Anything that does not resolve in the Forever client is skipped
  silently. Use  /easybuff debug  to print your current buffs (name + spellID) and
  add anything missing.
]]

local ADDON, ns = ...
local D = {}
ns.Data = D

local ALL_CLASSES = { "WARRIOR","PALADIN","HUNTER","ROGUE","PRIEST","SHAMAN","MAGE","WARLOCK","DRUID" }
D.ALL_CLASSES = ALL_CLASSES

local MANA  = { "MAGE","PRIEST","WARLOCK","PALADIN","SHAMAN","DRUID","HUNTER" }
local MELEE = { "WARRIOR","ROGUE","HUNTER","PALADIN","SHAMAN","DRUID" }

--------------------------------------------------------------------------
-- Individual buff definitions
--------------------------------------------------------------------------
local B = {}
D.buffs = B

-- ===== MAGE =====
B.AI        = { key="AI",       label="Arcane Int",  provider="MAGE",    ids={1459,1460,1461,10156,10157,23028}, names={"Arcane Intellect","Arcane Brilliance"}, classes=MANA }
B.MAGEARM   = { key="MAGEARM",  label="Armor",       provider="MAGE",    ids={168,7300,7301,7302,7320,10219,10220,6117,22782,22783}, names={"Frost Armor","Ice Armor","Mage Armor"}, cast={"Mage Armor","Ice Armor","Frost Armor"} }
B.DAMPEN    = { key="DAMPEN",   label="Dampen Magic",provider="MAGE",    ids={604,8450,8451,10173,10174}, names={"Dampen Magic"}, off=true }
B.AMPLIFY   = { key="AMPLIFY",  label="Amplify Magic",provider="MAGE",   ids={1008,8455,10169,10170}, names={"Amplify Magic"}, off=true }
B.MANASHIELD= { key="MANASHIELD",label="Mana Shield",provider="MAGE",    ids={1463,8494,8495,10191,10192,10193}, names={"Mana Shield"}, off=true }
B.ICEBARRIER= { key="ICEBARRIER",label="Ice Barrier",provider="MAGE",    ids={11426,13031,13032,13033}, names={"Ice Barrier"}, off=true }

-- ===== PRIEST =====
B.FORT      = { key="FORT",     label="Fortitude",   provider="PRIEST",  ids={1243,1244,1245,2791,10937,10938,21562,21564}, names={"Power Word: Fortitude","Prayer of Fortitude"} }
B.SPIRIT    = { key="SPIRIT",   label="Spirit",      provider="PRIEST",  ids={14752,14818,14819,27841,27681}, names={"Divine Spirit","Prayer of Spirit"}, classes=MANA }
B.INNERFIRE = { key="INNERFIRE",label="Inner Fire",  provider="PRIEST",  ids={588,7128,602,1006,10951,10952}, names={"Inner Fire"} }
B.SHADOWPROT= { key="SHADOWPROT",label="Shadow Prot",provider="PRIEST",  ids={976,10957,10958,27683,27684}, names={"Shadow Protection","Prayer of Shadow Protection"} }
B.PWS       = { key="PWS",      label="PW: Shield",  provider="PRIEST",  ids={17,592,600,3747,6065,6066,10898,10899,10900,10901}, names={"Power Word: Shield"}, off=true }
B.FEARWARD  = { key="FEARWARD", label="Fear Ward",   provider="PRIEST",  ids={6346}, names={"Fear Ward"}, off=true }
-- Priest racials
B.SHADOWGUARD={ key="SHADOWGUARD",label="Shadowguard",provider="PRIEST", ids={18137,19308,19309,19310,19311,19312}, names={"Shadowguard"} }          -- Troll
B.TOUCHWEAK = { key="TOUCHWEAK",label="Touch of Weak.",provider="PRIEST",ids={2652,19261,19262,19264,19265,19266}, names={"Touch of Weakness"}, off=true } -- Undead
B.ELUNESGRACE={ key="ELUNESGRACE",label="Elune's Grace",provider="PRIEST",ids={2651,19289,19291,19292,19293}, names={"Elune's Grace"}, off=true }          -- Night Elf
B.FEEDBACK  = { key="FEEDBACK", label="Feedback",    provider="PRIEST",  ids={13896,19271,19273,19274,19275}, names={"Feedback"}, off=true }              -- Human

-- ===== DRUID =====
B.MOTW      = { key="MOTW",     label="Mark of Wild",provider="DRUID",   ids={1126,5232,6756,5234,8907,9884,9885,21849,21850}, names={"Mark of the Wild","Gift of the Wild"} }
B.THORNS    = { key="THORNS",   label="Thorns",      provider="DRUID",   ids={467,782,1075,8914,9756,9910}, names={"Thorns"}, classes={"WARRIOR","PALADIN","DRUID","ROGUE"} }
B.OMEN      = { key="OMEN",     label="Omen of Clarity", provider="DRUID", ids={16864}, names={"Omen of Clarity"} }
B.NATGRASP  = { key="NATGRASP", label="Nature's Grasp", provider="DRUID", ids={16689,16810,16811,16812,16813,17329}, names={"Nature's Grasp"}, off=true }

-- ===== PALADIN =====
B.MIGHT     = { key="MIGHT",    label="Might",       provider="PALADIN", ids={19740,19834,19835,19836,19837,19838,25291}, names={"Blessing of Might"}, classes=MELEE }
B.WISDOM    = { key="WISDOM",   label="Wisdom",      provider="PALADIN", ids={19742,19850,19852,19853,19854,25290}, names={"Blessing of Wisdom"}, classes={"MAGE","PRIEST","WARLOCK","HUNTER","PALADIN","SHAMAN","DRUID"} }
B.KINGS     = { key="KINGS",    label="Kings",       provider="PALADIN", ids={20217}, names={"Blessing of Kings"} }
B.SALVATION = { key="SALVATION",label="Salvation",   provider="PALADIN", ids={1038,25895}, names={"Blessing of Salvation"}, off=true }
B.LIGHT     = { key="LIGHT",    label="Light",       provider="PALADIN", ids={19977,19978,19979}, names={"Blessing of Light"}, off=true }
B.SANCTUARY = { key="SANCTUARY",label="Sanctuary",   provider="PALADIN", ids={20911,20912,20913}, names={"Blessing of Sanctuary"}, off=true }
-- Self: "any blessing" (a Paladin can bless himself)
B.BLESS     = { key="BLESS",    label="Blessing",    provider="PALADIN",
                ids={19740,19834,19835,19836,19837,19838,25291, 19742,19850,19852,19853,19854,25290,
                     20217, 1038,25895, 19977,19978,19979, 20911,20912,20913},
                names={"Blessing of Might","Blessing of Wisdom","Blessing of Kings","Blessing of Salvation",
                       "Blessing of Light","Blessing of Sanctuary"},
                cast={"Blessing of Kings","Blessing of Might","Blessing of Wisdom"} }
B.PALAURA   = { key="PALAURA",  label="Aura",        provider="PALADIN",
                ids={465,10290,643,10291,1032,10292,10293, 7294,10298,10299,10300,10301, 19746,
                     19876,19895,19896, 19888,19897,19898, 19891,19899,19900, 20218},
                names={"Devotion Aura","Retribution Aura","Concentration Aura","Shadow Resistance Aura",
                       "Frost Resistance Aura","Fire Resistance Aura","Sanctity Aura"} }
B.SEAL      = { key="SEAL",     label="Seal",        provider="PALADIN",
                ids={20154,20287,20288,20289,20290,20291,20292,20293, 20375,20915,20918,20919,20920,
                     21082,20162,20305,20306,20307,20308, 20164, 20165,20347,20348,20349, 20166,20356,20357},
                names={"Seal of Righteousness","Seal of Command","Seal of the Crusader","Seal of Justice",
                       "Seal of Light","Seal of Wisdom"}, off=true }
B.RFURY     = { key="RFURY",    label="Righteous Fury", provider="PALADIN", ids={25780}, names={"Righteous Fury"}, off=true }

-- ===== WARRIOR =====
B.BSHOUT    = { key="BSHOUT",   label="Battle Shout",provider="WARRIOR", ids={6673,5242,6192,11549,11550,11551}, names={"Battle Shout"}, classes={"WARRIOR","ROGUE","HUNTER","PALADIN","SHAMAN","DRUID"} }

-- ===== WARLOCK =====
B.DEMONARMOR= { key="DEMONARMOR",label="Demon Armor",provider="WARLOCK", ids={687,696,706,1086,11733,11734,11735}, names={"Demon Skin","Demon Armor"} }
B.SOULLINK  = { key="SOULLINK", label="Soul Link",   provider="WARLOCK", ids={19028}, names={"Soul Link"}, off=true }
B.UNENDING  = { key="UNENDING", label="Unending Br.",provider="WARLOCK", ids={5697}, names={"Unending Breath"}, off=true }
B.SOULSTONE = { key="SOULSTONE",label="Soulstone",   provider="WARLOCK", ids={20707,20762,20763,20764,20765}, names={"Soulstone Resurrection"}, off=true }

-- ===== HUNTER =====
B.ASPECT    = { key="ASPECT",   label="Aspect",      provider="HUNTER",
                ids={13165,14318,14319,14320,14321,14322,25296, 5118, 13163, 13159, 20043,20190, 13161},
                names={"Aspect of the Hawk","Aspect of the Cheetah","Aspect of the Monkey","Aspect of the Pack",
                       "Aspect of the Wild","Aspect of the Beast"} }
B.TRUESHOT  = { key="TRUESHOT", label="Trueshot",    provider="HUNTER",  ids={19506,20905,20906}, names={"Trueshot Aura"}, classes=MELEE }

-- ===== SHAMAN =====
B.LSHIELD   = { key="LSHIELD",  label="Lightning Shield", provider="SHAMAN", ids={324,325,905,945,8134,10431,10432}, names={"Lightning Shield"} }
-- Shaman totem auras (only real auras on you while standing in range; all off by default)
B.TOTEM_STR = { key="TOTEM_STR",label="Str of Earth",provider="SHAMAN",  ids={8076,8162,8163,10441,25362}, names={"Strength of Earth"}, classes=MELEE, off=true }
B.TOTEM_AGI = { key="TOTEM_AGI",label="Grace of Air",provider="SHAMAN",  ids={8836,10626,25360}, names={"Grace of Air"}, classes=MELEE, off=true }
B.TOTEM_WF  = { key="TOTEM_WF", label="Windfury",    provider="SHAMAN",  ids={8515,10609,10608}, names={"Windfury Totem"}, classes=MELEE, off=true }
B.TOTEM_MANA= { key="TOTEM_MANA",label="Mana Spring",provider="SHAMAN",  ids={5677,10491,10493,10494}, names={"Mana Spring"}, classes=MANA, off=true }
B.TOTEM_HEAL= { key="TOTEM_HEAL",label="Healing Str.",provider="SHAMAN", ids={5672,6371,6372,10460,10461}, names={"Healing Stream"}, off=true }
B.TOTEM_SKIN= { key="TOTEM_SKIN",label="Stoneskin",  provider="SHAMAN",  ids={8072,8156,8157,10403,10404,10405}, names={"Stoneskin"}, off=true }

--------------------------------------------------------------------------
-- Buffs the player can put on himself, per class (order = display order)
-- Racial self buffs are listed for everyone of that class; they are only
-- reminded when the spell is actually in your spellbook.
--------------------------------------------------------------------------
D.selfBuffs = {
    MAGE    = { B.AI, B.MAGEARM, B.DAMPEN, B.AMPLIFY, B.MANASHIELD, B.ICEBARRIER },
    PRIEST  = { B.FORT, B.INNERFIRE, B.SPIRIT, B.SHADOWPROT, B.SHADOWGUARD,
                B.FEARWARD, B.PWS, B.TOUCHWEAK, B.ELUNESGRACE, B.FEEDBACK },
    DRUID   = { B.MOTW, B.THORNS, B.OMEN, B.NATGRASP },
    PALADIN = { B.BLESS, B.PALAURA, B.SEAL, B.RFURY },
    WARRIOR = { B.BSHOUT },
    WARLOCK = { B.DEMONARMOR, B.SOULLINK, B.UNENDING },
    HUNTER  = { B.ASPECT, B.TRUESHOT },
    SHAMAN  = { B.LSHIELD },
    ROGUE   = {},
}

--------------------------------------------------------------------------
-- Buffs OTHER classes in the group can give you
--------------------------------------------------------------------------
D.groupBuffs = {
    B.AI, B.FORT, B.SPIRIT, B.SHADOWPROT, B.MOTW, B.THORNS,
    B.KINGS, B.MIGHT, B.WISDOM, B.SALVATION, B.LIGHT, B.SANCTUARY,
    B.BSHOUT, B.TRUESHOT, B.SOULSTONE,
    B.TOTEM_STR, B.TOTEM_AGI, B.TOTEM_WF, B.TOTEM_MANA, B.TOTEM_HEAL, B.TOTEM_SKIN,
}

--------------------------------------------------------------------------
-- Consumables (matched against buff NAMES, English client, plain substring)
--------------------------------------------------------------------------
-- "Well Fed" food buffs. Item IDs are only used for the icon.
D.food = {
    key = "FOOD", label = "Food", iconItem = 20452,
    patterns = { "Well Fed", "Increased Agility", "Increased Stamina", "Increased Intellect",
                 "Increased Spirit", "Increased Strength", "Mana Regeneration", "Gordok Green Grog",
                 "Rumsey Rum", "Blessed Sunfruit" },
    suggest = {
        WARRIOR = "Smoked Desert Dumplings (Str), Dirge's Kickin' Chimaerok Chops (Sta)",
        PALADIN = "Smoked Desert Dumplings (Str), Nightfin Soup (mp5), Dirge's Chops (Sta)",
        HUNTER  = "Grilled Squid (Agi), Smoked Desert Dumplings (Str)",
        ROGUE   = "Grilled Squid (Agi), Smoked Desert Dumplings (Str)",
        PRIEST  = "Nightfin Soup (mp5), Runn Tum Tuber Surprise (Int), Tender Wolf Steak",
        SHAMAN  = "Nightfin Soup (mp5), Runn Tum Tuber Surprise (Int)",
        MAGE    = "Runn Tum Tuber Surprise (Int), Nightfin Soup (mp5)",
        WARLOCK = "Runn Tum Tuber Surprise (Int), Dirge's Chops (Sta)",
        DRUID   = "Nightfin Soup (mp5), Grilled Squid (Agi, feral)",
    },
}

-- Flask / Elixir. A class is satisfied by ANY matching buff.
D.elixir = {
    key = "ELIXIR", label = "Elixir/Flask", iconItem = 13452,
    patterns = {
        WARRIOR = { "Mongoose","Giants","Brute Force","Titans","Superior Defense","Greater Agility","Fortitude","Greater Stoneshield","Juju Power","Juju Might" },
        ROGUE   = { "Mongoose","Greater Agility","Giants","Juju Power","Juju Might","Titans" },
        HUNTER  = { "Mongoose","Greater Agility","Giants","Distilled Wisdom","Titans","Juju Power" },
        MAGE    = { "Greater Arcane","Supreme Power","Greater Firepower","Frost Power","Shadow Power","Mageblood","Distilled Wisdom","Fire Power" },
        WARLOCK = { "Greater Arcane","Supreme Power","Shadow Power","Greater Firepower","Mageblood","Distilled Wisdom","Fire Power" },
        PRIEST  = { "Mageblood","Distilled Wisdom","Greater Arcane","Supreme Power","Shadow Power","Healing Power","Greater Intellect" },
        PALADIN = { "Mongoose","Giants","Titans","Superior Defense","Mageblood","Distilled Wisdom","Greater Arcane","Supreme Power","Healing Power","Fortitude","Brute Force" },
        SHAMAN  = { "Mageblood","Distilled Wisdom","Greater Arcane","Supreme Power","Healing Power","Mongoose","Giants","Greater Agility","Titans","Nature Power" },
        DRUID   = { "Mageblood","Distilled Wisdom","Greater Arcane","Supreme Power","Healing Power","Mongoose","Giants","Greater Agility","Titans","Nature Power" },
    },
    suggest = {
        WARRIOR = "Elixir of the Mongoose / Giants / Flask of the Titans (tank: Superior Defense)",
        ROGUE   = "Elixir of the Mongoose, Greater Agility",
        HUNTER  = "Elixir of the Mongoose, Greater Agility",
        MAGE    = "Greater Arcane Elixir / Flask of Supreme Power, Greater Firepower or Frost Power",
        WARLOCK = "Greater Arcane Elixir / Flask of Supreme Power, Shadow Power",
        PRIEST  = "Mageblood Potion, Flask of Distilled Wisdom, Greater Arcane / Shadow Power",
        PALADIN = "Mongoose/Giants (Ret), Titans/Superior Defense (Prot), Mageblood/Distilled Wisdom (Holy)",
        SHAMAN  = "Mageblood/Distilled Wisdom (Resto), Mongoose/Giants (Enh), Greater Arcane (Ele)",
        DRUID   = "Mageblood/Distilled Wisdom (Resto), Mongoose/Giants (Feral), Greater Arcane (Balance)",
    },
}

-- Zanza / Juju style extras (off by default: /easybuff unignore ZANZA)
D.zanza = {
    key = "ZANZA", label = "Zanza", iconItem = 20079, off = true,
    patterns = { "of Zanza" },
    suggest = "Spirit of Zanza (Spi/Sta), Sheen of Zanza (spell power), Swiftness of Zanza (speed)",
}

-- Weapon enchants (poisons, imbues, stones, oils). Checked via GetWeaponEnchantInfo.
D.weapon = {
    ROGUE   = { kind="Poison",          iconSpell=8681,  suggest="Instant Poison / Deadly Poison on both weapons" },
    SHAMAN  = { kind="Weapon Imbue",    iconSpell=8017,  needSpell=8017, suggest="Rockbiter / Flametongue / Windfury / Frostbrand Weapon" },
    WARRIOR = { kind="Sharpening Stone",iconItem=12404,  suggest="Dense Sharpening Stone, Elemental Sharpening Stone" },
    PALADIN = { kind="Sharpening Stone",iconItem=12404,  suggest="Dense Sharpening Stone (Ret/Prot) - Brilliant Mana Oil (Holy)" },
    MAGE    = { kind="Wizard Oil",      iconItem=20749,  suggest="Brilliant Wizard Oil" },
    WARLOCK = { kind="Wizard Oil",      iconItem=20749,  suggest="Brilliant Wizard Oil" },
    PRIEST  = { kind="Oil",             iconItem=20748,  suggest="Brilliant Mana Oil / Wizard Oil" },
}

--------------------------------------------------------------------------
-- RAID checklist (only used while you are in a raid group, /easybuff raid on|off)
--   classes  = classes it is ON for by default (nil = every class)
--   opt      = classes it is available for after  /easybuff unignore KEY
--   off      = disabled for everyone until /easybuff unignore KEY
--   patterns = plain-substring match on aura names; exact = exact aura names
--   iconItem = item ID used only for the icon (falls back to a ? icon)
-- Buff names are English. Run /easybuff debug while buffed to verify / fix a name.
--------------------------------------------------------------------------
local CASTR = { "MAGE","WARLOCK","PRIEST" }
local HEAL  = { "PRIEST","PALADIN","SHAMAN","DRUID" }

D.raid = {}

D.raid.flask = {
    key = "FLASK", label = "Flask", iconItem = 13510,
    patterns = { "Flask of", "Supreme Power", "Distilled Wisdom", "Chromatic Resistance" },
    suggest = "Flask of the Titans (tank/HP), Flask of Supreme Power (casters), Flask of Distilled Wisdom (healers), Flask of Chromatic Resistance",
}

-- Specific elixirs. Skipped entirely when a flask is active (a flask replaces them).
D.raid.elixirs = {
    { key="MONGOOSE",  label="Mongoose",     iconItem=13452, patterns={"Mongoose"},          classes={"WARRIOR","ROGUE","HUNTER"}, opt={"PALADIN","SHAMAN","DRUID"}, suggest="Elixir of the Mongoose (agi + crit)" },
    { key="GIANTS",    label="Giants",       iconItem=9206,  patterns={"Giants"},            classes={"WARRIOR","ROGUE"}, opt={"PALADIN","SHAMAN","DRUID","HUNTER"}, suggest="Elixir of the Giants (strength)" },
    { key="SUPDEF",    label="Sup. Defense", iconItem=13445, patterns={"Superior Defense"},  classes={}, opt={"WARRIOR","PALADIN","DRUID"}, suggest="Elixir of Superior Defense (tanks)" },
    { key="ELIXFORT",  label="Fortitude",    iconItem=3825,  patterns={"Elixir of Fortitude"}, classes={}, opt={"WARRIOR","PALADIN","DRUID"}, suggest="Elixir of Fortitude (health)" },
    { key="GARCANE",   label="Gr. Arcane",   iconItem=13454, patterns={"Greater Arcane"},    classes={"MAGE","WARLOCK"}, opt={"PRIEST","PALADIN","SHAMAN","DRUID"}, suggest="Greater Arcane Elixir (spell damage)" },
    { key="FIREPOWER", label="Gr. Firepower",iconItem=21546, patterns={"Greater Firepower"}, classes={}, opt={"MAGE","WARLOCK"}, suggest="Elixir of Greater Firepower (fire damage)" },
    { key="FROSTPOWER",label="Frost Power",  iconItem=17708, patterns={"Frost Power"},       classes={}, opt={"MAGE"}, suggest="Elixir of Frost Power (frost damage)" },
    { key="SHADOWPOWER",label="Shadow Power",iconItem=9264,  patterns={"Shadow Power"},      classes={"WARLOCK"}, opt={"PRIEST","MAGE"}, suggest="Elixir of Shadow Power (shadow damage)" },
    { key="MAGEBLOOD", label="Mageblood",    iconItem=20007, patterns={"Mageblood"},         classes=HEAL, opt={"MAGE","WARLOCK","HUNTER"}, suggest="Mageblood Potion (mp5)" },
    { key="HEALPOWER", label="Healing Power",iconItem=9155,  patterns={"Healing Power"},     classes={}, opt=HEAL, suggest="Elixir of Healing Power" },
    { key="NATPOWER",  label="Nature Power", patterns={"Nature Power"},                      classes={}, opt={"SHAMAN","DRUID"}, suggest="Elixir of Greater Nature Power" },
}

-- Everything else in a raid: scrolls, Deviate Delight, Zanza, Juju, Blasted Lands buffs.
D.raid.other = {
    -- Scrolls (buff names are the plain stat names)
    { key="SCR_AGI",  label="Scroll Agi",  iconItem=3012, exact={"Agility"},   classes={"WARRIOR","ROGUE","HUNTER"}, opt={"DRUID","SHAMAN","PALADIN"}, suggest="Scroll of Agility" },
    { key="SCR_STR",  label="Scroll Str",  iconItem=954,  exact={"Strength"},  classes={"WARRIOR","PALADIN"}, opt={"ROGUE","SHAMAN","DRUID"}, suggest="Scroll of Strength" },
    { key="SCR_INT",  label="Scroll Int",  iconItem=955,  exact={"Intellect"}, classes=CASTR, opt={"PALADIN","SHAMAN","DRUID","HUNTER"}, suggest="Scroll of Intellect" },
    { key="SCR_SPI",  label="Scroll Spi",  iconItem=1712, exact={"Spirit"},    classes=HEAL, opt={"MAGE","WARLOCK"}, suggest="Scroll of Spirit" },
    { key="SCR_STA",  label="Scroll Sta",  iconItem=1180, exact={"Stamina"},   suggest="Scroll of Stamina" },
    { key="SCR_PROT", label="Scroll Armor",iconItem=3013, exact={"Armor"},     classes={}, opt={"WARRIOR","PALADIN","DRUID","ROGUE","HUNTER","SHAMAN"}, suggest="Scroll of Protection" },

    -- Savory Deviate Delight (Flip Out = ninja, Yaaarrrr = pirate, 60 min)
    { key="DEVIATE",  label="Deviate Delight", iconItem=6657, ids={8219,8221}, exact={"Flip Out","Yaaarrrr"},
      suggest="Savory Deviate Delight (ninja/pirate, 60 min). Druids, Shamans and Warlocks lose it when they change form." },

    -- Zanza
    { key="ZANZA",    label="Zanza",       iconItem=20079, patterns={"of Zanza"}, suggest="Spirit of Zanza (Spi/Sta), Sheen of Zanza (spell power), Swiftness of Zanza (speed)" },

    -- Juju
    { key="JUJUPOWER",label="Juju Power",  iconItem=12451, patterns={"Juju Power"}, classes={"WARRIOR","ROGUE"}, opt={"PALADIN","SHAMAN","DRUID","HUNTER"}, suggest="Juju Power (+30 strength)" },
    { key="JUJUMIGHT",label="Juju Might",  iconItem=12460, patterns={"Juju Might"}, classes={"WARRIOR","ROGUE","HUNTER"}, opt={"PALADIN","SHAMAN","DRUID"}, suggest="Juju Might (+40 attack power)" },
    { key="JUJUFLURRY",label="Juju Flurry",iconItem=12450, patterns={"Juju Flurry"}, classes={"WARRIOR","ROGUE","SHAMAN"}, opt={"DRUID","PALADIN","HUNTER"}, suggest="Juju Flurry (+3% attack speed)" },
    { key="JUJUGUILE",label="Juju Guile",  iconItem=12458, patterns={"Juju Guile"}, classes=CASTR, opt={"PALADIN","SHAMAN","DRUID"}, suggest="Juju Guile (+intellect)" },
    { key="JUJUEMBER",label="Juju Ember",  iconItem=12455, patterns={"Juju Ember"}, off=true, suggest="Juju Ember (+fire resistance)" },
    { key="JUJUCHILL",label="Juju Chill",  iconItem=12457, patterns={"Juju Chill"}, off=true, suggest="Juju Chill (+frost resistance)" },
    { key="JUJUESCAPE",label="Juju Escape",iconItem=12459, patterns={"Juju Escape"}, off=true, suggest="Juju Escape (+dodge)" },

    -- Blasted Lands buffs
    { key="ROIDS",    label="R.O.I.D.S.",  iconItem=8410, patterns={"Rage of Ages"},         classes={"WARRIOR","ROGUE","PALADIN"}, opt={"SHAMAN","DRUID","HUNTER"}, suggest="R.O.I.D.S. (+strength)" },
    { key="SCORPOK",  label="Scorpok Assay",iconItem=8412, patterns={"Strike of the Scorpok"},classes={"WARRIOR","ROGUE","HUNTER"}, opt={"DRUID","SHAMAN","PALADIN"}, suggest="Ground Scorpok Assay (+agility)" },
    { key="LUNGJUICE",label="Lung Juice",  iconItem=8411, patterns={"Spirit of Boar"},       classes=HEAL, opt={"MAGE","WARLOCK"}, suggest="Lung Juice Cocktail (+stamina)" },
    { key="CORTEX",   label="Cortex",      iconItem=8423, patterns={"Infallible Mind"},      classes=CASTR, opt={"PALADIN","SHAMAN","DRUID"}, suggest="Cerebral Cortex Compound (+intellect)" },
    { key="GIZZARD",  label="Gizzard Gum", iconItem=8424, patterns={"Spiritual Domination"}, classes={"PRIEST","MAGE","WARLOCK"}, opt={"PALADIN","SHAMAN","DRUID"}, suggest="Gizzard Gum (+spirit)" },
}

-- What the weapon reminder click applies: item name words found in your bags (poisons, stones, oils),
-- or an imbue spell for Shamans (tried in this order).
D.weapon.ROGUE.itemPatterns   = { "Poison" }
D.weapon.WARRIOR.itemPatterns = { "Sharpening Stone", "Weightstone", "Whetstone" }
D.weapon.PALADIN.itemPatterns = { "Sharpening Stone", "Weightstone", "Whetstone" }
D.weapon.MAGE.itemPatterns    = { "Wizard Oil" }
D.weapon.WARLOCK.itemPatterns = { "Wizard Oil" }
D.weapon.PRIEST.itemPatterns  = { "Mana Oil", "Wizard Oil" }
D.weapon.SHAMAN.cast          = { "Windfury Weapon", "Flametongue Weapon", "Frostbrand Weapon", "Rockbiter Weapon" }

-- Pets: only reminded when the summon spell is known.
D.pet = {
    HUNTER  = { spell=883, label="Pet", icon="Interface\\Icons\\Ability_Hunter_BeastCall",  suggest="Call Pet" },
    WARLOCK = { spell=688, label="Pet", icon="Interface\\Icons\\Spell_Shadow_SummonImp",    suggest="Summon your demon" },
}
