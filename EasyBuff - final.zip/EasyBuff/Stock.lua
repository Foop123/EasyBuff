--[[
  EasyBuff - Stock.lua
  Low-supply tracker: counts consumables in your bags and raises an (orange,
  flashing) reminder when a count is at or below your chosen number, or when it
  is gone completely.

  Built-in categories are found by scanning bags by item type, so they do not
  depend on item IDs: food & drink, elixirs, flasks, arrows, bullets.
  Anything else can be added by item ID / link / name in the settings window.

  Missing-alert rule for built-in categories: the "alert at 0" only fires after
  you have carried at least one of that category, so a class that never uses
  flasks is not nagged forever.

  Performance: the bags are scanned once into a snapshot and reused until the
  bags change (Stock.Invalidate, called from BAG_UPDATE_DELAYED).
]]

local ADDON, ns = ...
local S = {}
ns.Stock = S

local QMARK = "Interface\\Icons\\INV_Misc_QuestionMark"
local ORANGE = { 1, 0.6, 0.1, 1 }

local function listHas(list, v)
    if not list then return false end
    for _, c in ipairs(list) do if c == v then return true end end
    return false
end

local function itemTex(id)
    if C_Item and C_Item.GetItemIconByID then return C_Item.GetItemIconByID(id) end
    return GetItemIcon and GetItemIcon(id) or nil
end

local function itemName(id)
    return C_Item.GetItemNameByID and C_Item.GetItemNameByID(id) or nil
end

S.CATS = {
    { key = "FOOD",    label = "Food & drink", iconItem = 20452, default = { enabled = true, threshold = 5,   missing = true } },
    { key = "ELIXIR",  label = "Elixirs",      iconItem = 13452, default = { enabled = true, threshold = 2,   missing = true } },
    { key = "FLASK",   label = "Flasks",       iconItem = 13510, default = { enabled = true, threshold = 1,   missing = true } },
    { key = "ARROWS",  label = "Arrows",       iconItem = 2512,  default = { enabled = true, threshold = 200, missing = true },
      classes = { "HUNTER", "ROGUE", "WARRIOR" }, ammo = true },
    { key = "BULLETS", label = "Bullets",      iconItem = 2516,  default = { enabled = true, threshold = 200, missing = true },
      classes = { "HUNTER", "ROGUE", "WARRIOR" }, ammo = true },
}

function S.Ensure(DB)
    DB.stockCats = DB.stockCats or {}
    DB.stockSeen = DB.stockSeen or {}
    DB.stockItems = DB.stockItems or {}
    if DB.stock == nil then DB.stock = true end
    for _, c in ipairs(S.CATS) do
        local st = DB.stockCats[c.key]
        if not st then st = {}; DB.stockCats[c.key] = st end
        for k, v in pairs(c.default) do if st[k] == nil then st[k] = v end end
    end
end

--------------------------------------------------------------------------
-- item classification (cached per item ID)
--------------------------------------------------------------------------
-- Item class / subclass (Mainline item types): Consumable 0 -> Elixir 2, Flask 3, Food & Drink 5;
-- Projectile 6 -> Arrow 2, Bullet 3. Names are a fallback when a client types them differently.
local classCache = {}      -- itemID -> category string, or false = "not one of ours"
local requested = {}       -- itemIDs whose data we already asked the server for

local function classify(itemID)
    local cached = classCache[itemID]
    if cached ~= nil then return cached or nil end

    local ok, _, _, _, _, _, classID, subID = pcall(C_Item.GetItemInfoInstant, itemID)
    if not ok or not classID then return nil end          -- not loaded yet: do not cache

    local cat
    if classID == 0 then
        if subID == 5 then cat = "FOOD"
        elseif subID == 2 then cat = "ELIXIR"
        elseif subID == 3 then cat = "FLASK"
        else
            local name = itemName(itemID)
            if name then
                if name:find("Flask of", 1, true) then cat = "FLASK"
                elseif name:find("Elixir of", 1, true) then cat = "ELIXIR" end
            elseif not requested[itemID] then
                -- name unknown: ask for it and look again when GET_ITEM_INFO_RECEIVED invalidates us
                requested[itemID] = true
                if C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, itemID) end
                return nil
            end
        end
    elseif classID == 6 then
        if subID == 2 then cat = "ARROWS" elseif subID == 3 then cat = "BULLETS" end
    end

    classCache[itemID] = cat or false
    return cat
end

--------------------------------------------------------------------------
-- bag snapshot
--------------------------------------------------------------------------
local snap, snapDirty = nil, true

function S.Invalidate() snapDirty = true end

local function snapshot()
    if snap and not snapDirty then return snap end
    snapDirty = false

    local totals = {}
    local last = (NUM_BAG_SLOTS or 4) + (NUM_REAGENTBAG_SLOTS or 1)
    for bag = 0, last do
        local slots = C_Container.GetContainerNumSlots(bag) or 0
        for slot = 1, slots do
            local info = C_Container.GetContainerItemInfo(bag, slot)
            if info and info.itemID then
                totals[info.itemID] = (totals[info.itemID] or 0) + (info.stackCount or 1)
            end
        end
    end
    -- ammo sitting in the ammo slot (older-style clients)
    local okA, ammoID = pcall(GetInventoryItemID, "player", 0)
    if okA and ammoID then
        local okN, n = pcall(GetInventoryItemCount, "player", 0)
        totals[ammoID] = (totals[ammoID] or 0) + ((okN and n) or 1)
    end

    local cats, best, bestN = {}, {}, {}
    for id, n in pairs(totals) do
        local cat = classify(id)
        if cat then
            cats[cat] = (cats[cat] or 0) + n
            if not bestN[cat] or n > bestN[cat] then best[cat], bestN[cat] = id, n end
        end
    end

    snap = { totals = totals, cats = cats, best = best, byPattern = {} }
    return snap
end

-- which ammo type the equipped ranged weapon uses (nil = no ammo weapon)
local function equippedAmmo()
    local ok, id = pcall(GetInventoryItemID, "player", 18)
    if not ok or not id then return nil end
    local ok2, _, _, _, _, _, classID, subID = pcall(C_Item.GetItemInfoInstant, id)
    if not ok2 or classID ~= 2 then return nil end
    if subID == 2 or subID == 18 then return "ARROWS" end    -- bow, crossbow
    if subID == 3 then return "BULLETS" end                  -- gun
    return nil
end

function S.CategoryCount(key) return snapshot().cats[key] or 0 end

-- most-stocked bag item of a built-in category (FOOD, ELIXIR, FLASK, ...), used for click-to-use
function S.BestItem(cat) return snapshot().best[cat] end

-- most-stocked bag item whose name contains any of the given (English) words
function S.FindByNames(patterns)
    local sn = snapshot()
    local hit = sn.byPattern[patterns]
    if hit ~= nil then return hit or nil end

    local bestID, bestN
    for id, n in pairs(sn.totals) do
        local name = itemName(id)
        if name then
            if not bestN or n > bestN then
                for _, p in ipairs(patterns) do
                    if name:find(p, 1, true) then bestID, bestN = id, n; break end
                end
            end
        elseif not requested[id] then
            requested[id] = true
            if C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, id) end
        end
    end
    sn.byPattern[patterns] = bestID or false
    return bestID
end

function S.ItemCount(id)
    if not id then return 0 end
    return (C_Item.GetItemCount(id, false) or 0)
end

function S.ItemName(it)
    return it.name or itemName(it.id) or ("Item " .. tostring(it.id))
end

--------------------------------------------------------------------------
-- evaluation -> list of reminders (same shape EasyBuff's renderer uses)
--------------------------------------------------------------------------
function S.Evaluate(DB, class)
    local out = {}
    local counts = snapshot().cats
    local ammo = equippedAmmo()

    for _, cat in ipairs(S.CATS) do
        local st = DB.stockCats[cat.key]
        local classOK = (not cat.classes) or listHas(cat.classes, class)
        local ammoOK = (not cat.ammo) or ammo == cat.key
        if st and st.enabled and classOK and ammoOK then
            local n = counts[cat.key] or 0
            if n > 0 then DB.stockSeen[cat.key] = true end
            local limit = st.threshold or 0
            local alert = (n > 0 and n <= limit) or (n == 0 and st.missing and DB.stockSeen[cat.key])
            if alert then
                out[#out + 1] = {
                    key = "STOCK_" .. cat.key,
                    icon = itemTex(cat.iconItem) or QMARK,
                    label = (n == 0 and "No " or "Low ") .. cat.label,
                    sub = (n == 0) and nil or (n .. " left"),
                    tip = (n == 0) and ("You are out of " .. cat.label:lower() .. ".")
                          or ("Only " .. n .. " " .. cat.label:lower() .. " left (alert at " .. limit .. " or fewer)."),
                    color = ORANGE, count = n,
                }
            end
        end
    end

    for _, it in ipairs(DB.stockItems) do
        if it.id and it.enabled ~= false then
            local n = S.ItemCount(it.id)
            local limit = it.threshold or 0
            local alert = (n > 0 and n <= limit) or (n == 0 and it.missing ~= false)
            if alert then
                local name = S.ItemName(it)
                out[#out + 1] = {
                    key = "STOCK_ITEM" .. it.id,
                    icon = itemTex(it.id) or QMARK,
                    label = name,
                    sub = (n == 0) and "none" or (n .. " left"),
                    tip = (n == 0) and (name .. ": none in your bags.")
                          or (name .. ": " .. n .. " left (alert at " .. limit .. " or fewer)."),
                    color = ORANGE, count = n,
                }
            end
        end
    end

    return out
end
